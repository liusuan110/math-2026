"""
T9: 接口版本与元数据测试 — 验证所有 stage 的接口完整性
"""

from __future__ import annotations

from pathlib import Path

import pytest


PROJECT_ROOT = Path(__file__).resolve().parents[2]
TRAINED_DETECT_WEIGHT = PROJECT_ROOT / "train_demo" / "detect_components" / "weights" / "best.pt"
TRAINED_POSE_WEIGHT = PROJECT_ROOT / "train_demo" / "models" / "weights" / "best.pt"


class TestInterfaceVersions:
    """T9: 接口版本验证."""

    def test_t9_1_s1_interface_version(self, blank_image_b64):
        """T9.1: S1 返回 interface_version=component_detect_v1"""
        from app.pipeline.stages.s1_detect import run_detect
        from tests.pipeline.mocks import MockComponentDetector

        mock_det = MockComponentDetector([
            {"class_name": "Resistor", "bbox": (100, 200, 300, 260), "confidence": 0.95}
        ])
        result = run_detect(
            images_b64=[blank_image_b64],
            detector=mock_det,
        )

        assert result["interface_version"] == "component_detect_v1"
        assert "detector_backend" in result

    def test_t9_2_s1_5_interface_version(self, blank_image_b64):
        """T9.2: S1.5 返回 interface_version=component_pin_detect_v1"""
        from app.pipeline.stages.s1_detect import run_detect
        from app.pipeline.stages.s1b_pin_detect import run_pin_detect
        from app.pipeline.vision.pin_model import PinRoiDetector
        from tests.pipeline.mocks import MockComponentDetector

        det = MockComponentDetector([
            {"class_name": "Resistor", "bbox": (100, 200, 300, 260), "confidence": 0.95}
        ])
        s1 = run_detect(images_b64=[blank_image_b64], detector=det)

        pin_det = PinRoiDetector(model_path=None, device="cpu")
        result = run_pin_detect(
            detections=s1["detections"],
            images_b64=[blank_image_b64],
            pin_detector=pin_det,
        )

        assert result["interface_version"] == "component_pin_detect_v1"
        assert result["pin_detector_mode"] == "unavailable"
        assert result["pin_detector_backend"] == "yolo_pose"

    def test_t9_3_s2_interface_version(self):
        """T9.3: S2 返回 interface_version=hole_mapping_v1"""
        from app.pipeline.stages.s2_mapping import run_mapping
        from app.pipeline.vision.calibrator import BreadboardCalibrator
        from tests.pipeline.fixtures import image_to_b64, make_blank_image

        calibrator = BreadboardCalibrator(rows=63, cols_per_side=5)
        components = [
            {
                "component_id": "R1",
                "component_type": "Resistor",
                "pins": [
                    {
                        "pin_id": 1, "pin_name": "pin1",
                        "keypoints_by_view": {"top": [160.0, 240.0]},
                        "visibility_by_view": {"top": 2},
                        "score_by_view": {"top": 0.95},
                        "source_by_view": {"top": "model"},
                        "confidence": 0.95, "source": "model",
                    },
                    {
                        "pin_id": 2, "pin_name": "pin2",
                        "keypoints_by_view": {"top": [340.0, 240.0]},
                        "visibility_by_view": {"top": 2},
                        "score_by_view": {"top": 0.95},
                        "source_by_view": {"top": "model"},
                        "confidence": 0.95, "source": "model",
                    },
                ],
            }
        ]

        result = run_mapping(
            components=components,
            calibrator=calibrator,
            image_shape=(480, 640),
            images_b64=[image_to_b64(make_blank_image())],
        )

        assert result["interface_version"] == "hole_mapping_v1"
        assert "board_schema_id" in result

    def test_t9_3a_topology_input_preserves_s2_evidence_metadata(self):
        """S2 新增的 evidence/fusion/snap 字段应继续传到 topology 输入层。"""
        from app.pipeline.topology_input import normalize_components_for_topology
        from app.domain.board_schema import BoardSchema

        schema = BoardSchema.default_breadboard()
        normalized = normalize_components_for_topology(
            components=[
                {
                    "component_id": "R1",
                    "component_type": "Resistor",
                    "pins": [
                        {
                            "pin_id": 1,
                            "pin_name": "pin1",
                            "hole_id": "A1",
                            "electrical_node_id": "ROW_1_L",
                            "confidence": 0.95,
                            "observations": [],
                            "source": "model",
                            "evidence_source": "left_front",
                            "decisive_view_id": "left_front",
                            "fusion_confidence": 0.73,
                            "fusion_margin": 0.21,
                            "cross_view_agreement": 0.5,
                            "snap_distance_px": 3.0,
                            "snap_confidence": 0.91,
                        }
                    ],
                }
            ],
            board_schema=schema,
        )

        pin = normalized[0].pins[0]
        assert pin.metadata["evidence_source"] == "left_front"
        assert pin.metadata["decisive_view_id"] == "left_front"
        assert pin.metadata["fusion_confidence"] == 0.73
        assert pin.metadata["fusion_margin"] == 0.21
        assert pin.metadata["cross_view_agreement"] == 0.5
        assert pin.metadata["snap_distance_px"] == 3.0
        assert pin.metadata["snap_confidence"] == 0.91

    def test_t9_4_s3_interface_fields(self):
        """S3 返回完整的接口字段"""
        from app.pipeline.stages.s3_topology import run_topology

        components = [
            {
                "component_id": "R1",
                "component_type": "Resistor",
                "pins": [
                    {
                        "pin_id": 1, "pin_name": "pin1",
                        "hole_id": "A1", "electrical_node_id": "ROW_1_L",
                        "confidence": 0.95, "observations": [],
                        "source": "model",
                    },
                    {
                        "pin_id": 2, "pin_name": "pin2",
                        "hole_id": "A3", "electrical_node_id": "ROW_3_L",
                        "confidence": 0.95, "observations": [],
                        "source": "model",
                    },
                ],
            }
        ]

        result = run_topology(components=components)

        assert "circuit_description" in result
        assert "netlist_v2" in result
        assert "topology_graph" in result
        assert "component_count" in result
        assert "duration_ms" in result

    def test_t9_5_s4_interface_fields(self):
        """S4 返回完整的接口字段"""
        from app.pipeline.stages.s3_topology import run_topology
        from app.pipeline.stages.s4_validate import run_validate

        components = [
            {
                "component_id": "R1",
                "component_type": "Resistor",
                "pins": [
                    {
                        "pin_id": 1, "pin_name": "pin1",
                        "hole_id": "A1", "electrical_node_id": "ROW_1_L",
                        "confidence": 0.95, "observations": [],
                        "source": "model",
                    },
                    {
                        "pin_id": 2, "pin_name": "pin2",
                        "hole_id": "A3", "electrical_node_id": "ROW_3_L",
                        "confidence": 0.95, "observations": [],
                        "source": "model",
                    },
                ],
            }
        ]

        s3 = run_topology(components=components)
        result = run_validate(
            topology_graph=s3["topology_graph"],
            reference_circuit=None,
            components=components,
        )

        required = [
            "risk_level", "diagnosis", "diagnostics",
            "risk_reasons", "details", "duration_ms",
            "is_correct", "similarity",
        ]
        for field in required:
            assert field in result, f"Missing S4 field: {field}"

    def test_t9_6_pin_source_field(self, blank_image_b64):
        """T9.4: 每个 pin 有 source 字段"""
        from app.pipeline.stages.s1_detect import run_detect
        from app.pipeline.stages.s1b_pin_detect import run_pin_detect
        from app.pipeline.vision.pin_model import PinRoiDetector
        from tests.pipeline.mocks import MockComponentDetector

        det = MockComponentDetector([
            {"class_name": "Resistor", "bbox": (100, 200, 300, 260), "confidence": 0.95}
        ])
        s1 = run_detect(images_b64=[blank_image_b64], detector=det)
        pin_det = PinRoiDetector(model_path=None, device="cpu")
        result = run_pin_detect(
            detections=s1["detections"],
            images_b64=[blank_image_b64],
            pin_detector=pin_det,
        )

        for comp in result["components"]:
            for pin_data in comp["pins"]:
                assert "source" in pin_data
                assert pin_data["source"] in ("model", "unavailable")

    def test_t9_7_pin_detector_backend_mode(self, blank_image_b64):
        """T9.5: pin_detector.backend_mode 透传到输出"""
        from app.pipeline.stages.s1_detect import run_detect
        from app.pipeline.stages.s1b_pin_detect import run_pin_detect
        from app.pipeline.vision.pin_model import PinRoiDetector
        from tests.pipeline.mocks import MockComponentDetector

        det = MockComponentDetector([
            {"class_name": "Resistor", "bbox": (100, 200, 300, 260), "confidence": 0.95}
        ])
        pin_det = PinRoiDetector(model_path=None, device="cpu")

        s1 = run_detect(images_b64=[blank_image_b64], detector=det)
        result = run_pin_detect(
            detections=s1["detections"],
            images_b64=[blank_image_b64],
            pin_detector=pin_det,
        )

        assert "pin_detector_mode" in result
        assert result["pin_detector_mode"] == "unavailable"
        assert "pin_detector_backend" in result
        assert result["pin_detector_backend"] == "yolo_pose"

    def test_t9_8_detector_contract_present(self, blank_image_b64):
        """S1 会透传 detector contract."""
        from app.pipeline.stages.s1_detect import run_detect
        from tests.pipeline.mocks import MockComponentDetector

        det = MockComponentDetector([
            {"class_name": "Resistor", "bbox": (100, 200, 300, 260), "confidence": 0.95}
        ])
        result = run_detect(images_b64=[blank_image_b64], detector=det)

        assert "detector_contract" in result
        assert result["detector_contract"]["task"] == "mock"

    def test_t9_9_pin_detector_contract_present(self, blank_image_b64):
        """S1.5 会透传 pin detector contract."""
        from app.pipeline.stages.s1_detect import run_detect
        from app.pipeline.stages.s1b_pin_detect import run_pin_detect
        from app.pipeline.vision.pin_model import PinRoiDetector
        from tests.pipeline.mocks import MockComponentDetector

        det = MockComponentDetector([
            {"class_name": "Resistor", "bbox": (100, 200, 300, 260), "confidence": 0.95}
        ])
        s1 = run_detect(images_b64=[blank_image_b64], detector=det)
        pin_det = PinRoiDetector(model_path=None, device="cpu")
        result = run_pin_detect(
            detections=s1["detections"],
            images_b64=[blank_image_b64],
            pin_detector=pin_det,
        )

        assert "pin_detector_contract" in result
        assert result["pin_detector_contract"]["task"] == "unknown"


class TestRealModelContracts:
    """真实模型权重的轻量合同检查（不要求成功加载 torch/ultralytics）."""

    def test_t9_10_default_model_paths_point_to_trained_weights_when_present(self):
        if not TRAINED_DETECT_WEIGHT.exists() or not TRAINED_POSE_WEIGHT.exists():
            pytest.skip("trained weights not available")

        assert TRAINED_DETECT_WEIGHT.name == "best.pt"
        assert TRAINED_POSE_WEIGHT.name == "best.pt"

    def test_t9_11_component_detector_rejects_pose_weight(self):
        from app.pipeline.vision.detector import ComponentDetector

        if not TRAINED_POSE_WEIGHT.exists():
            pytest.skip("pose weight not available")

        detector = ComponentDetector(model_path=None, device="cpu")
        ok = detector.load(str(TRAINED_POSE_WEIGHT))
        assert ok is False
        assert detector.model is None
        assert detector.model_contract["task"] == "pose"

    def test_t9_12_pin_detector_rejects_detect_weight(self):
        from app.pipeline.vision.pin_model import PinRoiDetector

        if not TRAINED_DETECT_WEIGHT.exists():
            pytest.skip("detect weight not available")

        detector = PinRoiDetector(model_path=None, device="cpu")
        ok = detector.load(str(TRAINED_DETECT_WEIGHT))
        assert ok is False
        assert detector.model is None
        assert detector.model_contract["task"] in {"detect", "obb"}

    def test_t9_13_real_weight_contracts_match_expected_tasks(self):
        from app.pipeline.vision.model_inspector import inspect_yolo_weight

        if not TRAINED_DETECT_WEIGHT.exists() or not TRAINED_POSE_WEIGHT.exists():
            pytest.skip("trained weights not available")

        detect_contract = inspect_yolo_weight(TRAINED_DETECT_WEIGHT)
        pose_contract = inspect_yolo_weight(TRAINED_POSE_WEIGHT)

        assert detect_contract["task"] in {"detect", "obb"}
        assert "resistor" in [str(name).lower() for name in detect_contract["names"]]
        assert pose_contract["task"] == "pose"
        assert "transistor_3pin" in [str(name).lower() for name in pose_contract["names"]]
