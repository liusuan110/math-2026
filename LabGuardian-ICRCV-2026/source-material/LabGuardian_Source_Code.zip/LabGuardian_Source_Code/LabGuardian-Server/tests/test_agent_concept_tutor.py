from app.agent.concepts import CONCEPT_LIBRARY, lookup_concept
from app.agent.contracts import (
    ContextPack,
    EvidenceRef,
    RuntimeEvidence,
)
from app.agent.intent import classify_intent
from app.agent.tools import (
    TeachingConceptLookupInput,
    teaching_concept_lookup_tool,
)
from app.agent.verification import verify_draft_answer
from app.schemas.angnt import AngntAskRequest, AngntCitation, AngntEvidence
from app.services.agent_service import (
    AgentService,
    _build_concept_not_found_prompt,
    _is_circuit_related_question,
)
from app.services.classroom_state import ClassroomState
from app.services.rag_service import RagService


def _service() -> AgentService:
    return AgentService(rag_service=RagService())


# WP-0 (2026-05-24): ``_FakeDatasheetRagService`` previously overrode the
# legacy ``RagService.answer_with_kb`` to assert it was *not* called by the
# new local-datasheet path. ``answer_with_kb`` and the legacy PDF KB path
# have now been removed from the agent main path entirely (see
# ``docs/retrieval-contract.md``), so the mock collapses to a tracker shell
# kept only to confirm no legacy call site re-emerges.
class _FakeDatasheetRagService(RagService):
    def __init__(self) -> None:
        super().__init__()
        self.last_top_k = 0


def _submit(service: AgentService, classroom: ClassroomState, *, mode: str, query: str):
    accepted = service.submit(
        AngntAskRequest(station_id="S01", query=query, mode=mode),
        classroom,
    )
    status = service.get_status(accepted.job_id)
    assert status.result is not None
    return status.result


# ---------- intent classifier ----------

def test_intent_classifier_routes_led_question_to_concept_tutor() -> None:
    assert classify_intent("为什么 LED 要串联电阻", evidence=None) == "concept_tutor"


def test_intent_classifier_routes_current_circuit_led_question_to_mixed() -> None:
    assert classify_intent("我这个电路为什么 LED 要串联电阻", evidence=None) == "mixed"


def test_intent_classifier_routes_rc_question_to_concept_tutor() -> None:
    assert classify_intent("什么是 RC 时间常数", evidence=None) == "concept_tutor"


def test_intent_classifier_routes_diagnosis_to_diagnostic() -> None:
    assert classify_intent("我这个电路哪里错了", evidence=None) == "diagnostic"


def test_intent_classifier_routes_colloquial_problem_question_to_diagnostic() -> None:
    assert classify_intent("这个有什么问题", evidence=None) == "diagnostic"
    assert classify_intent("帮我看看哪里不对", evidence=None) == "diagnostic"
    assert classify_intent("这个电路有什么具体的问题", evidence=None) == "diagnostic"
    assert classify_intent("它和参考电路有哪些差异", evidence=None) == "diagnostic"


def test_intent_classifier_routes_multimeter_to_lab_guidance() -> None:
    assert classify_intent("怎么用万用表检查短路", evidence=None) == "lab_guidance"


def test_intent_classifier_returns_mixed_when_concept_with_findings() -> None:
    evidence = RuntimeEvidence(station_id="S", findings=[])
    # Inject a fake finding by appending after construction.
    from app.agent.contracts import DiagnosticFinding

    evidence.findings.append(DiagnosticFinding(error_code="NODE_MISMATCH"))
    assert classify_intent("RC 时间常数和我现在的实验有什么关系", evidence=evidence) == "mixed"


def test_intent_classifier_returns_mixed_for_theory_question_even_with_findings() -> None:
    evidence = RuntimeEvidence(station_id="S", findings=[])
    from app.agent.contracts import DiagnosticFinding

    evidence.findings.append(DiagnosticFinding(error_code="NODE_MISMATCH"))
    assert classify_intent("电磁和电场磁场的关系是什么", evidence=evidence) == "mixed"


def test_intent_classifier_does_not_force_off_topic_into_diagnostic_with_findings() -> None:
    evidence = RuntimeEvidence(station_id="S", findings=[])
    from app.agent.contracts import DiagnosticFinding

    evidence.findings.append(DiagnosticFinding(error_code="NODE_MISMATCH"))
    assert classify_intent("今天中午吃什么", evidence=evidence) == "concept_tutor"


def test_intent_classifier_routes_vague_diagnostic_follow_up_to_diagnostic() -> None:
    evidence = RuntimeEvidence(station_id="S", findings=[])
    from app.agent.contracts import DiagnosticFinding

    evidence.findings.append(DiagnosticFinding(error_code="NODE_MISMATCH"))
    assert classify_intent("简单点，这是什么意思", evidence=evidence) == "diagnostic"


# ---------- teaching_concept_lookup_tool ----------

def test_teaching_concept_lookup_tool_returns_local_pack_by_keyword() -> None:
    result = teaching_concept_lookup_tool(TeachingConceptLookupInput(query="为什么 LED 要限流"))
    assert result.status == "ok"
    assert result.payload["concept"]["concept_id"] == "led_current_limit"
    assert result.payload["provider"] == "local_concept_library"


def test_teaching_concept_lookup_tool_supports_all_six_concepts() -> None:
    expected = {
        "breadboard_basics",
        "ohms_law",
        "led_current_limit",
        "rc_time_constant",
        "voltage_divider",
        "capacitor_filtering",
    }
    assert set(CONCEPT_LIBRARY.keys()) == expected
    for cid in expected:
        result = teaching_concept_lookup_tool(TeachingConceptLookupInput(concept_id=cid))
        assert result.status == "ok"
        assert result.payload["concept"]["concept_id"] == cid


def test_teaching_concept_lookup_tool_returns_not_found_on_miss() -> None:
    result = teaching_concept_lookup_tool(TeachingConceptLookupInput(query="量子隧穿"))
    assert result.status == "not_found"
    assert "available_concepts" in result.payload


def test_llm_fallback_prompt_uses_general_circuit_knowledge_on_kb_miss() -> None:
    evidence = RuntimeEvidence(
        station_id="S",
        risk_level="safe",
        error_codes=["NODE_MISMATCH"],
        diagnostics=["R1 连接错误"],
    )

    assert _is_circuit_related_question("电感为什么会阻碍电流变化")
    assert _is_circuit_related_question("LED为什么要限流")
    prompt = _build_concept_not_found_prompt(
        question="电感为什么会阻碍电流变化",
        evidence=evidence,
    )

    assert "问题类型：circuit_related" in prompt
    assert "通用电路知识直接回答" in prompt
    assert "不要编造当前电路的具体孔位" in prompt
    assert "楞次定律" in prompt
    assert "NODE_MISMATCH" not in prompt
    assert "R1 连接错误" not in prompt


def test_llm_fallback_prompt_redirects_off_topic_questions() -> None:
    evidence = RuntimeEvidence(
        station_id="S",
        risk_level="safe",
        error_codes=["NODE_MISMATCH"],
        diagnostics=["R1 连接错误"],
    )

    assert not _is_circuit_related_question("今天中午吃什么")
    assert not _is_circuit_related_question("music playlist")
    prompt = _build_concept_not_found_prompt(
        question="今天中午吃什么",
        evidence=evidence,
    )

    assert "问题类型：off_topic" in prompt
    assert "不要长篇展开非电路内容" in prompt
    assert "引导回电路" in prompt
    assert "NODE_MISMATCH" not in prompt
    assert "R1 连接错误" not in prompt


def test_llm_fallback_prompt_uses_current_context_only_for_follow_up() -> None:
    evidence = RuntimeEvidence(
        station_id="S",
        risk_level="warning",
        error_codes=["NODE_MISMATCH"],
        diagnostics=["R1 连接错误"],
    )

    prompt = _build_concept_not_found_prompt(
        question="简单点，这是什么意思",
        evidence=evidence,
    )

    assert "问题类型：current_context_follow_up" in prompt
    assert "NODE_MISMATCH" in prompt
    assert "R1 连接错误" in prompt


# ---------- verifier per intent ----------

def _stub_pack() -> ContextPack:
    return ContextPack(pack_id="p", error_family="unknown", risk_level="unknown")


def test_verifier_concept_mode_does_not_require_error_code() -> None:
    evidence = RuntimeEvidence(
        station_id="S",
        risk_level="safe",
        error_codes=["LED_MISSING_RESISTOR"],
    )
    concept = lookup_concept("LED 限流")
    draft = (
        "直接回答：LED 需要串联限流电阻。\n"
        "原理：欧姆定律 V=IR 用于估算限流。\n"
        "安全提醒：先断电再操作。\n"
        "知识来源：led_current_limit"
    )
    report = verify_draft_answer(
        evidence=evidence,
        context_pack=_stub_pack(),
        draft_answer=draft,
        intent="concept_tutor",
        concept=concept,
    )
    assert report.passed, report.issues


def test_verifier_diagnostic_requires_error_code_when_present() -> None:
    evidence = RuntimeEvidence(
        station_id="S",
        risk_level="safe",
        error_codes=["NODE_MISMATCH"],
    )
    report = verify_draft_answer(
        evidence=evidence,
        context_pack=_stub_pack(),
        draft_answer="R1 的连接节点与参考不符，请对照参考电路检查。",
        intent="diagnostic",
    )
    assert not report.passed
    assert any("error_code" in issue for issue in report.issues)


def test_verifier_diagnostic_requires_evidence_ref_when_present() -> None:
    evidence = RuntimeEvidence(
        station_id="S",
        risk_level="safe",
        evidence_refs=[
            EvidenceRef(
                ref_id="validator:1",
                component_id="R1",
                pin_name="A",
                hole_id="A1",
            )
        ],
    )
    report = verify_draft_answer(
        evidence=evidence,
        context_pack=_stub_pack(),
        draft_answer="当前连接与参考不一致，请重新核对。",
        intent="diagnostic",
    )
    assert not report.passed
    assert any(
        "evidence_ref" in issue or "component_id" in issue
        for issue in report.issues
    )


def test_verifier_diagnostic_passes_with_error_code_and_evidence_ref() -> None:
    evidence = RuntimeEvidence(
        station_id="S",
        risk_level="safe",
        error_codes=["NODE_MISMATCH"],
        evidence_refs=[
            EvidenceRef(
                ref_id="validator:1",
                component_id="R1",
                pin_name="A",
                hole_id="A1",
            )
        ],
    )
    report = verify_draft_answer(
        evidence=evidence,
        context_pack=_stub_pack(),
        draft_answer="NODE_MISMATCH 显示 R1 的 A 引脚连接与参考不一致，请核对 A1 孔位。",
        intent="diagnostic",
    )
    assert report.passed, report.issues


def test_verifier_concept_mode_blocks_fabricated_hole_when_no_evidence() -> None:
    evidence = RuntimeEvidence(station_id="S", risk_level="safe")
    concept = lookup_concept("LED 限流")
    bad_draft = (
        "原理：LED 限流。当前电路中 R1 接到了 ROW_5_L。\n"
        "安全提醒：先断电再操作。\n"
        "知识来源：led_current_limit"
    )
    report = verify_draft_answer(
        evidence=evidence,
        context_pack=_stub_pack(),
        draft_answer=bad_draft,
        intent="concept_tutor",
        concept=concept,
    )
    assert not report.passed
    assert any("没有 evidence" in issue or "孔位" in issue for issue in report.issues)


def test_verifier_lab_guidance_requires_steps_and_safety() -> None:
    evidence = RuntimeEvidence(station_id="S", risk_level="safe")
    fail = verify_draft_answer(
        evidence=evidence,
        context_pack=_stub_pack(),
        draft_answer="用万用表检查就行。",
        intent="lab_guidance",
    )
    assert not fail.passed
    good = verify_draft_answer(
        evidence=evidence,
        context_pack=_stub_pack(),
        draft_answer="1. 先断电。\n2. 用万用表通断挡测电源轨。",
        intent="lab_guidance",
    )
    assert good.passed, good.issues


def test_verifier_concept_mode_requires_safety_for_led_topic() -> None:
    evidence = RuntimeEvidence(station_id="S", risk_level="safe")
    concept = lookup_concept("LED 限流")
    no_safety = (
        "直接回答：LED 需要串联电阻。\n"
        "原理：欧姆定律。\n"
        "知识来源：led_current_limit"
    )
    report = verify_draft_answer(
        evidence=evidence,
        context_pack=_stub_pack(),
        draft_answer=no_safety,
        intent="concept_tutor",
        concept=concept,
    )
    assert not report.passed
    assert any("安全" in issue for issue in report.issues)


def test_verifier_diagnostic_intent_default_preserves_existing_behavior() -> None:
    """Regression: omitting intent keeps the diagnostic rule set."""
    evidence = RuntimeEvidence(station_id="S", risk_level="danger")
    report = verify_draft_answer(
        evidence=evidence,
        context_pack=_stub_pack(),
        draft_answer="电路有问题。",
    )
    assert not report.passed
    assert any("danger" in issue for issue in report.issues)


# ---------- agent_auto mode end-to-end ----------

def test_agent_auto_routes_led_question_to_concept_tutor() -> None:
    classroom = ClassroomState()
    result = _submit(_service(), classroom, mode="agent_auto", query="为什么 LED 要串联电阻")

    evidence_types = {item.evidence_type for item in result.evidence}
    assert "intent" in evidence_types
    intent_item = next(item for item in result.evidence if item.evidence_type == "intent")
    assert intent_item.payload["intent"] == "concept_tutor"
    assert "concept_pack" in evidence_types
    assert "知识来源" in result.answer
    assert result.mode == "agent_auto"


def test_agent_auto_routes_datasheet_pin_question_to_local_kb() -> None:
    """Post-Phase-5 contract: chip-parameter questions are answered directly
    from the local DatasheetKbService (knowledge/datasheets/*.json) without
    invoking any LLM. The legacy `_FakeDatasheetRagService` mock is no longer
    consulted because the outer gate + `_run_datasheet_kb_job` are gone."""

    classroom = ClassroomState()
    rag = _FakeDatasheetRagService()
    service = AgentService(rag_service=rag)
    result = _submit(service, classroom, mode="agent_auto", query="NE555的引脚有哪些")

    # No LLM involved — provider tag is the new local-kb marker.
    assert result.actual_llm_provider == "local_datasheet_kb"
    assert result.actual_llm_model == "no_llm"
    # Legacy answer_with_kb mock should not have been called.
    assert rag.last_top_k == 0
    # Answer contains a real chunk_id from knowledge/datasheets/ne555.json.
    assert "ne555." in result.answer
    assert "无 LLM 合成" in result.answer


def test_agent_auto_routes_rc_question_to_concept_tutor() -> None:
    classroom = ClassroomState()
    result = _submit(_service(), classroom, mode="agent_auto", query="什么是 RC 时间常数")

    intent_item = next(item for item in result.evidence if item.evidence_type == "intent")
    assert intent_item.payload["intent"] == "concept_tutor"
    concept_item = next(item for item in result.evidence if item.evidence_type == "concept_pack")
    assert concept_item.payload["concept_id"] == "rc_time_constant"


def test_agent_auto_routes_multimeter_to_lab_guidance() -> None:
    classroom = ClassroomState()
    result = _submit(_service(), classroom, mode="agent_auto", query="怎么用万用表检查短路")

    intent_item = next(item for item in result.evidence if item.evidence_type == "intent")
    assert intent_item.payload["intent"] == "lab_guidance"
    # Step markers and safety word must be in the answer (verifier-enforced).
    assert "1." in result.answer
    assert any(w in result.answer for w in ("断电", "电源", "短路"))


def test_agent_auto_routes_diagnostic_question_to_diagnostic_path() -> None:
    classroom = ClassroomState()
    classroom.update_station(
        {
            "station_id": "S01",
            "risk_level": "danger",
            "diagnostics": ["R1 两端短路"],
            "comparison_report": {
                "items": [
                    {
                        "error_code": "COMPONENT_SHORTED_SAME_NET",
                        "component_id": "R1",
                        "severity": "danger",
                    }
                ]
            },
        }
    )
    result = _submit(_service(), classroom, mode="agent_auto", query="我这个电路哪里错了")

    evidence_types = {item.evidence_type for item in result.evidence}
    # Diagnostic path emits runtime_evidence + context_pack + react_trace.
    assert "context_pack" in evidence_types
    assert "react_trace" in evidence_types
    assert any(w in result.answer for w in ("断电", "断开电源", "电源", "短路"))


def test_agent_auto_demo_prompt_with_next_step_keeps_diagnostic_context() -> None:
    classroom = ClassroomState()
    classroom.update_station(
        {
            "station_id": "S01",
            "risk_level": "warning",
            "diagnostics": ["R1 连接节点与参考不符"],
            "comparison_report": {
                "summary": {
                    "reference_id": "rc_first_order_v1",
                    "reference_name": "一阶 RC 电路",
                },
                "items": [
                    {
                        "error_code": "WRONG_CONNECTION",
                        "component_id": "R1",
                        "severity": "warning",
                        "suggested_action": "将 R1 改接到参考网络。",
                    }
                ],
            },
            "netlist_v2": {
                "components": [{"component_id": "R1", "component_type": "Resistor"}],
                "nets": [],
            },
        }
    )
    result = _submit(
        _service(),
        classroom,
        mode="agent_auto",
        query="请根据当前诊断结果给出演示用诊断解释和下一步建议。",
    )

    evidence_types = {item.evidence_type for item in result.evidence}
    assert "context_pack" in evidence_types
    assert "react_trace" in evidence_types
    first_sentence = result.answer.split("。", 1)[0]
    assert first_sentence.startswith("先看这个电路本身")
    assert "WRONG_CONNECTION" in first_sentence
    assert "一阶 RC 电路(rc_first_order_v1)" in first_sentence
    assert "R1(Resistor)" in first_sentence


def test_agent_auto_repair_followup_uses_existing_diagnostic_context() -> None:
    classroom = ClassroomState()
    classroom.update_station(
        {
            "station_id": "S01",
            "risk_level": "warning",
            "diagnostics": ["R1 连接节点与参考不符"],
            "comparison_report": {
                "items": [
                    {
                        "error_code": "WRONG_CONNECTION",
                        "component_id": "R1",
                        "severity": "warning",
                        "suggested_action": "将 R1 改接到参考网络。",
                    }
                ],
            },
            "netlist_v2": {
                "components": [{"component_id": "R1", "component_type": "Resistor"}],
                "nets": [],
            },
        }
    )
    result = _submit(_service(), classroom, mode="agent_auto", query="那我怎么改")

    evidence_types = {item.evidence_type for item in result.evidence}
    assert "context_pack" in evidence_types
    assert "react_trace" in evidence_types
    assert "WRONG_CONNECTION" in result.answer
    assert "R1" in result.answer


def test_agent_auto_how_to_do_followup_uses_existing_diagnostic_context() -> None:
    classroom = ClassroomState()
    classroom.update_station(
        {
            "station_id": "S01",
            "risk_level": "warning",
            "diagnostics": ["R1 连接节点与参考不符"],
            "comparison_report": {
                "items": [
                    {
                        "error_code": "WRONG_CONNECTION",
                        "component_id": "R1",
                        "severity": "warning",
                        "suggested_action": "将 R1 改接到参考网络。",
                    }
                ],
            },
            "netlist_v2": {
                "components": [{"component_id": "R1", "component_type": "Resistor"}],
                "nets": [],
            },
        }
    )
    result = _submit(_service(), classroom, mode="agent_auto", query="那我怎么做")

    evidence_types = {item.evidence_type for item in result.evidence}
    assert "context_pack" in evidence_types
    assert "react_trace" in evidence_types
    assert "WRONG_CONNECTION" in result.answer
    assert "R1" in result.answer


def test_agent_auto_followup_uses_diagnostics_even_without_structured_findings() -> None:
    classroom = ClassroomState()
    classroom.update_station(
        {
            "station_id": "S01",
            "risk_level": "warning",
            "diagnostics": ["reference_circuit: provided 仍无法完成验证"],
            "risk_reasons": ["参考电路与当前识别结果不匹配"],
        }
    )
    result = _submit(_service(), classroom, mode="agent_auto", query="那我怎么做")

    evidence_types = {item.evidence_type for item in result.evidence}
    assert "context_pack" in evidence_types
    assert "react_trace" in evidence_types
    assert "reference_circuit" in result.answer or "参考电路" in result.answer


def test_agent_auto_improvement_followup_defaults_to_current_circuit() -> None:
    classroom = ClassroomState()
    classroom.update_station(
        {
            "station_id": "S01",
            "risk_level": "warning",
            "diagnostics": ["R1 连接节点与参考不符"],
            "comparison_report": {
                "items": [
                    {
                        "error_code": "WRONG_CONNECTION",
                        "component_id": "R1",
                        "severity": "warning",
                        "suggested_action": "将 R1 改接到参考网络。",
                    }
                ],
            },
            "netlist_v2": {
                "components": [{"component_id": "R1", "component_type": "Resistor"}],
                "nets": [],
            },
        }
    )
    result = _submit(_service(), classroom, mode="agent_auto", query="后续怎么完善")

    evidence_types = {item.evidence_type for item in result.evidence}
    assert "context_pack" in evidence_types
    assert "react_trace" in evidence_types
    assert "llm_fallback" not in result.answer
    assert "WRONG_CONNECTION" in result.answer
    assert "R1" in result.answer


def test_agent_auto_mixed_returns_diagnostic_answer_and_attaches_concept() -> None:
    classroom = ClassroomState()
    classroom.update_station(
        {
            "station_id": "S01",
            "risk_level": "warning",
            "diagnostics": ["R1 NODE_MISMATCH"],
            "comparison_report": {
                "items": [
                    {
                        "error_code": "NODE_MISMATCH",
                        "component_id": "R1",
                        "severity": "warning",
                    }
                ]
            },
        }
    )
    result = _submit(
        _service(),
        classroom,
        mode="agent_auto",
        query="RC 时间常数和我现在的实验有什么关系",
    )

    evidence_types = {item.evidence_type for item in result.evidence}
    assert "context_pack" in evidence_types
    assert "react_trace" in evidence_types
    assert "tool_results" in evidence_types
    assert "intent" in evidence_types
    intent_item = next(item for item in result.evidence if item.evidence_type == "intent")
    assert intent_item.payload["intent"] == "mixed"
    assert "concept_pack" in evidence_types
    assert "NODE_MISMATCH" in result.answer
    assert "R1" in result.answer


# ---------- direct concept_tutor / lab_guidance modes ----------

def test_explicit_concept_tutor_mode_runs_without_findings() -> None:
    classroom = ClassroomState()
    result = _submit(_service(), classroom, mode="concept_tutor", query="什么是欧姆定律")

    assert "知识来源" in result.answer
    concept_item = next(item for item in result.evidence if item.evidence_type == "concept_pack")
    assert concept_item.payload["concept_id"] == "ohms_law"


def test_explicit_lab_guidance_mode_returns_steps_and_safety() -> None:
    classroom = ClassroomState()
    result = _submit(_service(), classroom, mode="lab_guidance", query="怎么用万用表检查短路")

    assert "1." in result.answer
    assert any(w in result.answer for w in ("断电", "电源", "短路"))


# ---------- regression: diagnostic_agent unchanged ----------

def test_diagnose_mode_still_falls_back_to_rag() -> None:
    """Regression: mode="diagnose" must NOT be diverted into concept routing."""
    classroom = ClassroomState()
    classroom.update_station({"station_id": "S01", "risk_level": "safe"})
    result = _submit(_service(), classroom, mode="diagnose", query="为什么 LED 要串联电阻")
    # The diagnose/RAG path does NOT emit intent / concept_pack evidence items.
    evidence_types = {item.evidence_type for item in result.evidence}
    assert "intent" not in evidence_types
    assert "concept_pack" not in evidence_types
