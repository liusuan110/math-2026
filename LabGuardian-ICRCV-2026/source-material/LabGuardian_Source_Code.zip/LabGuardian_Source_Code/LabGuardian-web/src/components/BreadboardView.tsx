import { useEffect, useMemo, useRef, useState } from "react";
import type {
  CircuitAnalysisResult,
  PipelineResult,
  PortAnnotation,
  PortVisualizationResult,
  ManualNetRoleAssignment,
  EvidenceRef,
  LogicalReference,
  LogicalReferenceNet,
} from "../types/pipeline";
import {
  ALL_STRIPS,
  BREADBOARD_COLS,
  BOT_LETTERS,
  HALF_BOUNDARY,
  TOP_LETTERS,
  buildBreadboardModel,
  getNetColor,
  holeKey,
  parseHoleId,
  pinKeyOf,
  type BreadboardPinRef,
  type RailKind,
  type StripKind,
} from "../utils/breadboard";
import { buildPortAnnotation, portAnnotationKey } from "../utils/portAnnotation";
import {
  isPortReferenceNet,
  normalizeReferenceRole,
  referenceNetLabel,
} from "../utils/referenceRoles";

type Props = {
  result: PipelineResult | CircuitAnalysisResult | PortVisualizationResult | null;
  corrections: Map<string, string>;
  onCorrectionChange: (corrections: Map<string, string>) => void;
  onResetCorrections: () => void;
  onApplyCorrections: () => void;
  isApplyingCorrections?: boolean;
  selectedReferenceId?: string | null;
  currentReference?: LogicalReference | null;
  portAnnotations?: Map<string, PortAnnotation>;
  onPortAnnotationChange?: (key: string, annotation: PortAnnotation | null) => void;
  onResetPortAnnotations?: () => void;
  netRoleAssignments?: Map<string, ManualNetRoleAssignment>;
  onNetRoleChange?: (key: string, assignment: ManualNetRoleAssignment | null) => void;
  onResetNetRoles?: () => void;
  highlightTargets?: EvidenceRef[];
  pinPolarityAssignments?: Map<string, "E" | "B" | "C">;
  onPinPolarityChange?: (key: string, polarity: "E" | "B" | "C" | null) => void;
  onResetPinPolarities?: () => void;
};

// SVG 几何参数
const PAD_X = 28;
const PAD_Y = 22;
const COL_STEP = 13;       // 60 列下每列横向间距
const ROW_STEP = 18;       // 每行纵向间距
const RAIL_GAP = 14;       // 轨与矩阵之间的空隙
const CENTER_GAP = 22;     // 中央 E↔F 之间的凹槽
const CENTER_X_GAP = 14;   // 中央左右半之间的横向断开 (col 30↔31)
const HOLE_R = 4.4;        // 孔半径
const USED_GLOW = 9;       // 已用孔的外圈半径

const RAIL_LABELS: Record<RailKind, string> = {
  top_plus: "+",
  top_minus: "−",
  bot_plus: "+",
  bot_minus: "−",
};

const RAIL_TINT: Record<RailKind, string> = {
  top_plus: "#dc2626",
  top_minus: "#1d4ed8",
  bot_plus: "#dc2626",
  bot_minus: "#1d4ed8",
};

function colX(col: number) {
  // 60 列板：col 31 起整体右移 CENTER_X_GAP 体现物理中央断开
  const extra = col > HALF_BOUNDARY ? CENTER_X_GAP : 0;
  return PAD_X + (col - 1) * COL_STEP + extra;
}

function railY(rail: RailKind): number {
  // 顺序：top_plus(0), top_minus(1), [matrix top A-E], gap, [matrix bot F-J], bot_plus, bot_minus
  if (rail === "top_plus") return PAD_Y;
  if (rail === "top_minus") return PAD_Y + ROW_STEP;
  // 计算矩阵下方位置
  const topRailsBottom = PAD_Y + ROW_STEP;
  const matrixTopStart = topRailsBottom + RAIL_GAP;
  const matrixTopEnd = matrixTopStart + (TOP_LETTERS.length - 1) * ROW_STEP;
  const matrixBotStart = matrixTopEnd + CENTER_GAP;
  const matrixBotEnd = matrixBotStart + (BOT_LETTERS.length - 1) * ROW_STEP;
  if (rail === "bot_plus") return matrixBotEnd + RAIL_GAP;
  return matrixBotEnd + RAIL_GAP + ROW_STEP; // bot_minus
}

function matrixY(letter: string): number {
  const topIdx = TOP_LETTERS.indexOf(letter as (typeof TOP_LETTERS)[number]);
  const topRailsBottom = PAD_Y + ROW_STEP;
  const matrixTopStart = topRailsBottom + RAIL_GAP;
  if (topIdx >= 0) return matrixTopStart + topIdx * ROW_STEP;
  const botIdx = BOT_LETTERS.indexOf(letter as (typeof BOT_LETTERS)[number]);
  const matrixTopEnd = matrixTopStart + (TOP_LETTERS.length - 1) * ROW_STEP;
  const matrixBotStart = matrixTopEnd + CENTER_GAP;
  return matrixBotStart + botIdx * ROW_STEP;
}

const BOARD_WIDTH = PAD_X * 2 + (BREADBOARD_COLS - 1) * COL_STEP + CENTER_X_GAP;
const BOARD_HEIGHT = railY("bot_minus") + PAD_Y;

const STRIP_PAD = 7;
const STRIP_WIDTH = HOLE_R * 2 + 6;
const STRIP_HEIGHT = HOLE_R * 2 + 6;
const ROUTE_LANE_OFFSETS = [-10, -6, -2, 2, 6, 10];

type StripGeom = { x: number; y: number; w: number; h: number; cx: number; cy: number; rx: number };

function stripGeometry(kind: StripKind): StripGeom {
  if (kind.kind === "matrix") {
    const letters = kind.half === "top" ? TOP_LETTERS : BOT_LETTERS;
    const yTop = matrixY(letters[0]) - STRIP_PAD;
    const yBot = matrixY(letters[letters.length - 1]) + STRIP_PAD;
    const x = colX(kind.col) - STRIP_WIDTH / 2;
    return {
      x,
      y: yTop,
      w: STRIP_WIDTH,
      h: yBot - yTop,
      cx: colX(kind.col),
      cy: (yTop + yBot) / 2,
      rx: STRIP_WIDTH / 2,
    };
  }
  // rail half: L 段覆盖 col 1..HALF_BOUNDARY，R 段覆盖 col HALF_BOUNDARY+1..BREADBOARD_COLS
  const startCol = kind.half === "L" ? 1 : HALF_BOUNDARY + 1;
  const endCol = kind.half === "L" ? HALF_BOUNDARY : BREADBOARD_COLS;
  const x = colX(startCol) - 8;
  const xEnd = colX(endCol) + 8;
  const w = xEnd - x;
  const y = railY(kind.rail) - STRIP_HEIGHT / 2;
  return {
    x,
    y,
    w,
    h: STRIP_HEIGHT,
    cx: x + w / 2,
    cy: railY(kind.rail),
    rx: STRIP_HEIGHT / 2,
  };
}

type Hover = {
  x: number;
  y: number;
  sourceHoleKey?: string;
  netId: string;
  netRole: string;
  pins: BreadboardPinRef[];
} | null;

type DragState = {
  pinKey: string;        // componentId::pinName
  componentId: string;
  pinName: string;
  origHoleKey: string;   // 起始孔 key (M:A12 / R:top_plus:5)
  netId: string;
  netRole: string;
  cursorBoardX: number;  // 当前光标在 SVG viewBox 坐标系内的位置
  cursorBoardY: number;
};

type Point = { x: number; y: number };

type NetRoute = {
  netId: string;
  role: string;
  color: string;
  points: Point[];
  busY: number;
  d: string;
  labelX: number;
  labelY: number;
};

type WireSegment = {
  componentId: string;
  netId: string;
  color: string;
  a: Point;
  b: Point;
};

function isPowerRole(role: string) {
  return role === "VCC" || role === "VEE" || role === "GND";
}

function buildRoutePath(points: Point[], busY: number) {
  const xs = points.map((p) => p.x);
  const minX = Math.min(...xs) - 10;
  const maxX = Math.max(...xs) + 10;
  const branches = points.map((p) => `M ${p.x.toFixed(1)} ${p.y.toFixed(1)} V ${busY.toFixed(1)}`);
  return [`M ${minX.toFixed(1)} ${busY.toFixed(1)} H ${maxX.toFixed(1)}`, ...branches].join(" ");
}
export function BreadboardView({
  result,
  corrections,
  onCorrectionChange,
  onResetCorrections,
  onApplyCorrections,
  isApplyingCorrections = false,
  selectedReferenceId = null,
  currentReference = null,
  portAnnotations = new Map(),
  onPortAnnotationChange,
  onResetPortAnnotations,
  netRoleAssignments = new Map(),
  onNetRoleChange,
  onResetNetRoles,
  highlightTargets = [],
  pinPolarityAssignments = new Map(),
  onPinPolarityChange,
  onResetPinPolarities,
}: Props) {
  const model = useMemo(() => buildBreadboardModel(result, corrections), [result, corrections]);
  const [hover, setHover] = useState<Hover>(null);
  const [hoverNet, setHoverNet] = useState<string | null>(null);
  const [selectedNet, setSelectedNet] = useState<string | null>(null);
  const [activePortRefNet, setActivePortRefNet] = useState<string | null>(null);
  const activeNet = hoverNet ?? selectedNet;
  const [drag, setDrag] = useState<DragState | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);

  const portRefNets = useMemo(
    () => (currentReference?.nets ?? []).filter(isPortReferenceNet),
    [currentReference],
  );

  const annotationByNetId = useMemo(() => {
    const map = new Map<string, PortAnnotation>();
    for (const annotation of portAnnotations.values()) {
      const netId = annotation.target.electrical_net_id;
      if (netId) map.set(netId, annotation);
    }
    return map;
  }, [portAnnotations]);

  const portRefToNetId = useMemo(() => {
    const map = new Map<string, string>();
    for (const annotation of portAnnotations.values()) {
      const label = (annotation.label ?? "").toUpperCase();
      const netId = annotation.target.electrical_net_id;
      if (label && netId) map.set(label, netId);
    }
    return map;
  }, [portAnnotations]);

  const activePortRef = portRefNets.find((refNet) => refNet.net === activePortRefNet) ?? null;

  useEffect(() => {
    if (portRefNets.length === 0) {
      setActivePortRefNet(null);
      return;
    }
    setActivePortRefNet((current) => {
      if (current && portRefNets.some((refNet) => refNet.net === current)) return current;
      const firstUnassigned = portRefNets.find(
        (refNet) => !portRefToNetId.has(referenceNetLabel(refNet).toUpperCase()),
      );
      return firstUnassigned?.net ?? portRefNets[0]?.net ?? null;
    });
  }, [portRefNets, portRefToNetId]);

  const highlightSets = useMemo(() => {
    const compIds = new Set<string>();
    const holeIds = new Set<string>();
    const netIds = new Set<string>();
    for (const t of highlightTargets) {
      switch (t.type) {
        case "component":
          compIds.add(t.component_id);
          break;
        case "pin":
          compIds.add(t.component_id);
          if (t.hole_id) holeIds.add(t.hole_id);
          break;
        case "net":
          for (const pins of model.holes.values()) {
            for (const pin of pins) {
              if (pin.electricalNetId === t.electrical_net_id) {
                netIds.add(pin.netId);
              }
            }
          }
          break;
        case "reference_component":
          break;
      }
    }
    return { compIds, holeIds, netIds };
  }, [highlightTargets, model]);

  const usedNetIds = Array.from(model.netHoles.entries())
    .sort(([a], [b]) => {
      const aP = /VCC|VEE|GND/.test(a.toUpperCase());
      const bP = /VCC|VEE|GND/.test(b.toUpperCase());
      if (aP && !bP) return -1;
      if (!aP && bP) return 1;
      return a.localeCompare(b);
    })
    .map(([id]) => id);

  const allPins = useMemo(() => {
    const map = new Map<string, BreadboardPinRef>();
    for (const pins of model.holes.values()) {
      for (const pin of pins) {
        const key = pinKeyOf(pin.componentId, pin.pinName);
        if (!map.has(key)) map.set(key, pin);
      }
    }
    return Array.from(map.values()).sort(
      (a, b) => a.componentId.localeCompare(b.componentId) || a.pinName.localeCompare(b.pinName),
    );
  }, [model]);

  function compactRoleClass(label: string | null | undefined, role: string) {
    const normalizedLabel = (label ?? "").toLowerCase().replace(/[^a-z0-9_-]+/g, "");
    return normalizedLabel || role;
  }

  function refNetRoleClass(refNet: LogicalReferenceNet): string {
    const label = referenceNetLabel(refNet);
    return compactRoleClass(label, normalizeReferenceRole(refNet.role, label));
  }

  function annotationRoleClass(annotation: PortAnnotation): string {
    return compactRoleClass(annotation.label, annotation.role);
  }

  function pinsForNet(netId: string): BreadboardPinRef[] {
    const pins: BreadboardPinRef[] = [];
    for (const holePins of model.holes.values()) {
      for (const pin of holePins) {
        if (pin.netId === netId || pin.electricalNetId === netId) pins.push(pin);
      }
    }
    return pins;
  }

  function assignPortRefToNet(refNet: LogicalReferenceNet, netId: string, pins?: BreadboardPinRef[]) {
    if (!onPortAnnotationChange) return;
    const refLabel = referenceNetLabel(refNet).toUpperCase();
    const previousNetId = portRefToNetId.get(refLabel);
    if (previousNetId && previousNetId !== netId) {
      onPortAnnotationChange(portAnnotationKey(previousNetId), null);
    }

    const currentAnnotation = annotationByNetId.get(netId);
    const currentLabel = (currentAnnotation?.label ?? "").toUpperCase();
    if (currentAnnotation && currentLabel !== refLabel) {
      onPortAnnotationChange(portAnnotationKey(netId), null);
    }

    const annotation = buildPortAnnotation(refNet, netId);
    if (!annotation) return;
    const pin = pins?.[0];
    // R11 follow-up — the LOCAL_NET_<i> ids minted by
    // recomputeNetIdsByStrip() are frontend-only synthetic
    // identifiers; the backend has no such net so passing them
    // through here would short-circuit _resolve_net (it'd try
    // electrical_net_id first, miss, and silently drop the whole
    // annotation). Drop the field when it's synthetic so the
    // backend falls back to hole_id / component+pin / node_id
    // (all stable across the recompute pass).
    const rawNetId = pin?.electricalNetId ?? netId;
    const isSyntheticNet =
      typeof rawNetId === "string" && rawNetId.startsWith("LOCAL_NET_");
    onPortAnnotationChange(portAnnotationKey(netId), {
      ...annotation,
      target: {
        ...annotation.target,
        component_id: pin?.componentId ?? annotation.target.component_id,
        pin_name: pin?.pinName ?? annotation.target.pin_name,
        hole_id: pin?.holeId ?? annotation.target.hole_id,
        electrical_node_id: pin?.electricalNodeId ?? annotation.target.electrical_node_id,
        electrical_net_id: isSyntheticNet ? undefined : rawNetId,
      },
    });
    setSelectedNet(netId);

    const nextRef = portRefNets.find((candidate) => {
      const label = referenceNetLabel(candidate).toUpperCase();
      return candidate.net !== refNet.net && !portRefToNetId.has(label);
    });
    setActivePortRefNet(nextRef?.net ?? refNet.net);
  }

  function handleVisualNetClick(netId: string, pins?: BreadboardPinRef[]) {
    if (activePortRef && onPortAnnotationChange) {
      assignPortRefToNet(activePortRef, netId, pins);
      return;
    }
    setSelectedNet((cur) => (cur === netId ? null : netId));
  }

  function handlePolarityChange(pin: BreadboardPinRef, polarity: string) {
    if (!onPinPolarityChange) return;
    const key = `${pin.componentId}.${pin.pinName}`;
    if (!polarity) {
      onPinPolarityChange(key, null);
      return;
    }
    if (polarity === "E" || polarity === "B" || polarity === "C") {
      onPinPolarityChange(key, polarity);
    }
  }

  function displayPolarity(pin: BreadboardPinRef): string {
    const key = `${pin.componentId}.${pin.pinName}`;
    const manual = pinPolarityAssignments.get(key);
    if (manual) return manual;
    if (pin.polarityRole && pin.polarityRole !== "UNKNOWN") return pin.polarityRole;
    if (pin.polarityCandidateRole && pin.polarityCandidateRole !== "UNKNOWN") return pin.polarityCandidateRole;
    return pin.pinDisplayName ?? pin.pinName;
  }

  if (!result || (model.holes.size === 0 && model.unresolvedPins.length === 0)) {
    return (
      <section className="netlist-panel">
        <div className="panel-heading">
          <h2>面包板可视化</h2>
        </div>
        <p className="muted">网表将在 S3 拓扑阶段完成后显示。</p>
      </section>
    );
  }

  // 用 holeKey 反查每个孔的位置
  function holePos(key: string): { x: number; y: number } | null {
    if (key.startsWith("M:")) {
      const m = key.slice(2).match(/^([A-J])(\d+)$/);
      if (!m) return null;
      return { x: colX(parseInt(m[2], 10)), y: matrixY(m[1]) };
    }
    if (key.startsWith("R:")) {
      const parts = key.split(":");
      const rail = parts[1] as RailKind;
      const col = parseInt(parts[2], 10);
      return { x: colX(col), y: railY(rail) };
    }
    return null;
  }

  /** 元件锚点 = 该元件全部已用孔位置的平均坐标 */
  function componentAnchor(componentId: string): { x: number; y: number } | null {
    const holes = model.componentHoles.get(componentId);
    if (!holes || holes.size === 0) return null;
    const pts = Array.from(holes)
      .map((k) => holePos(k))
      .filter((p): p is { x: number; y: number } => Boolean(p));
    if (pts.length === 0) return null;
    const sx = pts.reduce((s, p) => s + p.x, 0) / pts.length;
    const sy = pts.reduce((s, p) => s + p.y, 0) / pts.length;
    return { x: sx, y: sy };
  }

  /** 悬停某个孔时，找到同一元件的其它孔位，用于显示“这个元件的另一端在哪里”。 */
  function pairedHolesForHover(): Array<{ key: string; x: number; y: number; pins: BreadboardPinRef[] }> {
    if (!hover?.sourceHoleKey) return [];
    const paired = new Map<string, { key: string; x: number; y: number; pins: BreadboardPinRef[] }>();
    hover.pins.forEach((pin) => {
      const holes = model.componentHoles.get(pin.componentId);
      if (!holes) return;
      holes.forEach((key) => {
        if (key === hover.sourceHoleKey) return;
        const pos = holePos(key);
        const pins = model.holes.get(key);
        if (!pos || !pins) return;
        paired.set(key, { key, x: pos.x, y: pos.y, pins });
      });
    });
    return Array.from(paired.values());
  }

  /** 找离 (board x, y) 最近的孔 (matrix + rail，全部遍历)。返回 holeKey 或 null。 */
  function nearestHoleKey(bx: number, by: number, maxDistPx: number): string | null {
    let best: { key: string; d2: number } | null = null;
    // matrix
    const letters: readonly string[] = [...TOP_LETTERS, ...BOT_LETTERS];
    for (const l of letters) {
      const ly = matrixY(l);
      for (let c = 1; c <= BREADBOARD_COLS; c++) {
        const lx = colX(c);
        const dx = lx - bx;
        const dy = ly - by;
        const d2 = dx * dx + dy * dy;
        if (best === null || d2 < best.d2) {
          best = { key: holeKey({ kind: "matrix", letter: l, row: c }), d2 };
        }
      }
    }
    // rails
    const rails: RailKind[] = ["top_plus", "top_minus", "bot_plus", "bot_minus"];
    for (const r of rails) {
      const ry = railY(r);
      for (let c = 1; c <= BREADBOARD_COLS; c++) {
        const rx = colX(c);
        const dx = rx - bx;
        const dy = ry - by;
        const d2 = dx * dx + dy * dy;
        if (best === null || d2 < best.d2) {
          best = { key: holeKey({ kind: "rail", rail: r, col: c }), d2 };
        }
      }
    }
    if (!best) return null;
    return Math.sqrt(best.d2) <= maxDistPx ? best.key : null;
  }

  /** 把屏幕坐标 (clientX/Y) 转成 SVG viewBox 内的坐标 */
  function clientToBoard(clientX: number, clientY: number): { x: number; y: number } | null {
    const svg = svgRef.current;
    if (!svg) return null;
    const rect = svg.getBoundingClientRect();
    if (rect.width === 0) return null;
    const scale = rect.width / BOARD_WIDTH;
    return {
      x: (clientX - rect.left) / scale,
      y: (clientY - rect.top) / scale,
    };
  }

  /** 全局拖拽监听：drag 状态期间订阅 mousemove / mouseup */
  useEffect(() => {
    if (!drag) return;
    const onMove = (e: MouseEvent) => {
      const pt = clientToBoard(e.clientX, e.clientY);
      if (!pt) return;
      setDrag((cur) => (cur ? { ...cur, cursorBoardX: pt.x, cursorBoardY: pt.y } : cur));
    };
    const onUp = (e: MouseEvent) => {
      const pt = clientToBoard(e.clientX, e.clientY);
      setDrag((cur) => {
        if (!cur) return cur;
        if (pt) {
          // 拖拽距离极小（< 0.4 pitch ≈ 5 px）当作普通点击
          const moved = Math.hypot(pt.x - cur.cursorBoardX, pt.y - cur.cursorBoardY) > 0.5;
          const fromCursor = pt;
          const target = nearestHoleKey(fromCursor.x, fromCursor.y, COL_STEP * 1.2);
          if (target && (target !== cur.origHoleKey || moved)) {
            const next = new Map(corrections);
            if (target === cur.origHoleKey) {
              // 拖回原位 → 撤销修正
              next.delete(cur.pinKey);
            } else {
              next.set(cur.pinKey, target);
            }
            onCorrectionChange(next);
          }
        }
        return null; // 结束拖拽
      });
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [drag !== null]);

  function startDrag(e: React.MouseEvent, pin: BreadboardPinRef, origKey: string) {
    e.preventDefault();
    e.stopPropagation();
    const pt = clientToBoard(e.clientX, e.clientY);
    const orig = holePos(origKey);
    setDrag({
      pinKey: pinKeyOf(pin.componentId, pin.pinName),
      componentId: pin.componentId,
      pinName: pin.pinName,
      origHoleKey: origKey,
      netId: pin.netId,
      netRole: model.netRoles.get(pin.netId) ?? "SIGNAL",
      cursorBoardX: pt?.x ?? orig?.x ?? 0,
      cursorBoardY: pt?.y ?? orig?.y ?? 0,
    });
  }

  function resetCorrections() {
    onResetCorrections();
    if (onResetPortAnnotations) onResetPortAnnotations();
    if (onResetNetRoles) onResetNetRoles();
  }

  function netRoute(netId: string, routeIndex: number): NetRoute | null {
    const role = model.netRoles.get(netId) ?? "SIGNAL";
    if (isPowerRole(role)) return null;

    const points = (model.netHoles.get(netId) ?? [])
      .map((k) => holePos(k))
      .filter((p): p is Point => Boolean(p))
      .filter((p, index, arr) => arr.findIndex((item) => item.x === p.x && item.y === p.y) === index)
      .sort((a, b) => a.x - b.x || a.y - b.y);

    if (points.length < 2) return null;

    const color = getNetColor(netId, role);
    const centerY = (matrixY("E") + matrixY("F")) / 2;
    const avgY = points.reduce((sum, p) => sum + p.y, 0) / points.length;
    const laneOffset = ROUTE_LANE_OFFSETS[routeIndex % ROUTE_LANE_OFFSETS.length];
    const busY = centerY + laneOffset;

    const minX = Math.min(...points.map((p) => p.x));
    return {
      netId,
      role,
      color,
      points,
      busY,
      d: buildRoutePath(points, busY),
      labelX: Math.max(PAD_X + 18, minX - 14),
      labelY: busY - 5,
    };
  }

  const netRoutes = usedNetIds
    .map((netId, index) => netRoute(netId, index))
    .filter((route): route is NetRoute => Boolean(route));

  const wireSegments: WireSegment[] = Array.from(model.componentTypes.entries()).flatMap(
    ([componentId, componentType]) => {
      if (componentType.toLowerCase() !== "wire") return [];
      const holeKeys = Array.from(model.componentHoles.get(componentId) ?? [])
        .sort()
        .slice(0, 2);
      if (holeKeys.length < 2) return [];
      const a = holePos(holeKeys[0]);
      const b = holePos(holeKeys[1]);
      if (!a || !b) return [];
      const pins = [
        ...(model.holes.get(holeKeys[0]) ?? []),
        ...(model.holes.get(holeKeys[1]) ?? []),
      ];
      const ownPin = pins.find((pin) => pin.componentId === componentId);
      const netId = ownPin?.netId ?? "";
      const role = model.netRoles.get(netId) ?? "SIGNAL";
      return [
        {
          componentId,
          netId,
          color: getNetColor(netId || componentId, role),
          a,
          b,
        },
      ];
    },
  );

  return (
    <section className="netlist-panel">
      <div className="panel-heading">
        <h2>面包板可视化网表</h2>
        <span>
          {usedNetIds.length} nets · {Array.from(model.holes.values()).reduce((sum, l) => sum + l.length, 0)} pins
          {corrections.size > 0 || portAnnotations.size > 0 || netRoleAssignments.size > 0 ? (
            <>
              {" "}
              ·{" "}
              <button
                type="button"
                className="bb-reset-btn"
                onClick={resetCorrections}
                title="撤销所有手工修正"
              >
                ↺ 重置
                {corrections.size > 0 ? ` ${corrections.size} 项孔位修正` : ""}
                {corrections.size > 0 && (portAnnotations.size > 0 || netRoleAssignments.size > 0) ? " +" : ""}
                {portAnnotations.size > 0 ? ` ${portAnnotations.size} 项端口` : ""}
                {portAnnotations.size > 0 && netRoleAssignments.size > 0 ? " +" : ""}
                {netRoleAssignments.size > 0 ? ` ${netRoleAssignments.size} 项角色` : ""}
              </button>
            </>
          ) : null}
        </span>
      </div>

      {portRefNets.length > 0 && onPortAnnotationChange ? (
        <div className="board-role-toolbar">
          <div className="board-role-buttons">
            <button
              type="button"
              className={`board-role-button ${activePortRefNet === null ? "active" : ""}`}
              onClick={() => setActivePortRefNet(null)}
            >
              浏览
            </button>
            {portRefNets.map((refNet) => {
              const label = referenceNetLabel(refNet);
              const role = normalizeReferenceRole(refNet.role, label);
              const assignedNetId = portRefToNetId.get(label.toUpperCase());
              return (
                <button
                  key={refNet.net}
                  type="button"
                  className={`board-role-button role-${refNetRoleClass(refNet)} ${activePortRefNet === refNet.net ? "active" : ""}${assignedNetId ? " assigned" : ""}`}
                  onClick={() => setActivePortRefNet((current) => (current === refNet.net ? null : refNet.net))}
                  title={assignedNetId ? `${label} -> ${assignedNetId}` : `${label} · ${role}`}
                >
                  <span className={`net-role-badge role-${role}`}>{role}</span>
                  <strong>{label}</strong>
                  <span className="board-role-target">{assignedNetId ?? "未绑定"}</span>
                </button>
              );
            })}
          </div>
          {portAnnotations.size > 0 ? (
            <div className="bb-role-summary-list">
              {Array.from(portAnnotations.entries()).map(([key, annotation]) => {
                const netId = annotation.target.electrical_net_id;
                if (!netId) return null;
                const label = annotation.label ?? annotation.role;
                return (
                  <span key={key} className={`bb-role-summary-item role-${annotationRoleClass(annotation)}`}>
                    <span className={`net-role-badge role-${annotation.role}`}>{label}</span>
                    <span className="bb-role-summary-target">{netId}</span>
                    <button
                      type="button"
                      className="bb-role-remove-btn"
                      onClick={() => onPortAnnotationChange(key, null)}
                      title={`移除 ${label}`}
                    >
                      ×
                    </button>
                  </span>
                );
              })}
            </div>
          ) : null}
        </div>
      ) : null}

      <div className="breadboard-wrap">
        <svg
          ref={svgRef}
          className={`breadboard-svg${drag ? " dragging" : ""}`}
          viewBox={`0 0 ${BOARD_WIDTH} ${BOARD_HEIGHT}`}
          width="100%"
          preserveAspectRatio="xMidYMid meet"
          style={{ aspectRatio: `${BOARD_WIDTH} / ${BOARD_HEIGHT}` }}
        >
          {/* 板子背景 */}
          <rect
            x={4}
            y={4}
            width={BOARD_WIDTH - 8}
            height={BOARD_HEIGHT - 8}
            rx={10}
            ry={10}
            fill="#f7f3ea"
            stroke="#d6cfbf"
            strokeWidth={1.5}
          />

          {/* 中央水平凹槽 (E↔F 之间) */}
          {(() => {
            const topRailsBottom = PAD_Y + ROW_STEP;
            const matrixTopStart = topRailsBottom + RAIL_GAP;
            const matrixTopEnd = matrixTopStart + (TOP_LETTERS.length - 1) * ROW_STEP;
            return (
              <rect
                x={PAD_X - 12}
                y={matrixTopEnd + ROW_STEP / 2}
                width={BOARD_WIDTH - (PAD_X - 12) * 2}
                height={CENTER_GAP - ROW_STEP}
                fill="#e8e0cd"
                stroke="#cbc3ad"
                strokeWidth={0.8}
              />
            );
          })()}

          {/* 中央垂直分隔 (col 30 ↔ col 31)：物理上左右两半电源轨在此断开 */}
          {(() => {
            const xMid = colX(HALF_BOUNDARY) + COL_STEP / 2 + CENTER_X_GAP / 2;
            return (
              <rect
                x={xMid - CENTER_X_GAP / 2}
                y={PAD_Y - 8}
                width={CENTER_X_GAP}
                height={BOARD_HEIGHT - (PAD_Y - 8) * 2}
                fill="#ece4cf"
                stroke="#cbc3ad"
                strokeWidth={0.8}
                strokeDasharray="3 2"
              />
            );
          })()}

          {/* 0.5: strip lanes (面包板天然电气连接) */}
          {ALL_STRIPS.map(({ id, kind }) => {
            const g = stripGeometry(kind);
            const usage = model.stripUsage.get(id);
            const railTint = kind.kind === "rail" ? RAIL_TINT[kind.rail] : null;
            if (usage) {
              const color = getNetColor(usage.netId, usage.role);
              const isActive = activeNet === usage.netId;
              const isDim = activeNet !== null && !isActive;
              const isHighlightedNet = highlightSets.netIds.has(usage.netId);
              return (
                <g
                  key={`strip-${id}`}
                  className={`bb-strip used${isHighlightedNet ? " highlighted" : ""}`}
                  style={{ opacity: isDim ? 0.18 : 1 }}
                  onMouseEnter={(e) => {
                    const svgRect = (e.currentTarget.ownerSVGElement as SVGSVGElement).getBoundingClientRect();
                    const scale = svgRect.width / BOARD_WIDTH;
                    setHoverNet(usage.netId);
                    setHover({
                      x: svgRect.left + g.cx * scale + 8,
                      y: svgRect.top + g.cy * scale - 8,
                      netId: usage.netId,
                      netRole: usage.role,
                      pins: usage.pins,
                    });
                  }}
                  onMouseLeave={() => {
                    setHover(null);
                    setHoverNet(null);
                  }}
                  onClick={() => handleVisualNetClick(usage.netId, usage.pins)}
                >
                  <rect
                    x={g.x}
                    y={g.y}
                    width={g.w}
                    height={g.h}
                    rx={g.rx}
                    ry={g.rx}
                    fill={color}
                    fillOpacity={isActive ? 0.28 : isHighlightedNet ? 0.38 : 0.16}
                    stroke={color}
                    strokeOpacity={isActive ? 0.85 : isHighlightedNet ? 0.95 : 0.55}
                    strokeWidth={isHighlightedNet ? 2.0 : 1.2}
                  />
                </g>
              );
            }
            // 空 strip：仅显示一条非常淡的导电带
            return (
              <rect
                key={`strip-${id}`}
                x={g.x}
                y={g.y}
                width={g.w}
                height={g.h}
                rx={g.rx}
                ry={g.rx}
                fill={railTint ?? "#a8a092"}
                fillOpacity={railTint ? 0.07 : 0.06}
                stroke={railTint ?? "#cbc3ad"}
                strokeOpacity={0.25}
                strokeWidth={0.7}
              />
            );
          })}

          {/* 2. 全部空孔（背景） */}
          {Array.from({ length: BREADBOARD_COLS }, (_, i) => i + 1).map((col) =>
            [...TOP_LETTERS, ...BOT_LETTERS].map((letter) => {
              const k = holeKey({ kind: "matrix", row: col, letter });
              if (model.holes.has(k)) return null;
              return (
                <circle
                  key={`empty-${k}`}
                  cx={colX(col)}
                  cy={matrixY(letter)}
                  r={HOLE_R - 1}
                  fill="#1f2937"
                  fillOpacity={0.08}
                />
              );
            }),
          )}
          {(["top_plus", "top_minus", "bot_plus", "bot_minus"] as RailKind[]).flatMap((rail) =>
            Array.from({ length: BREADBOARD_COLS }, (_, i) => i + 1).map((col) => {
              const k = holeKey({ kind: "rail", rail, col });
              if (model.holes.has(k)) return null;
              return (
                <circle
                  key={`empty-${k}`}
                  cx={colX(col)}
                  cy={railY(rail)}
                  r={HOLE_R - 1.4}
                  fill={RAIL_TINT[rail]}
                  fillOpacity={0.18}
                />
              );
            }),
          )}

          {/* 2.4: 物理跳线。每根 Wire 只画自己的两个端点，避免电源/地 net 被画成一大片。 */}
          {wireSegments.map((segment) => {
            const isDim = activeNet !== null && activeNet !== segment.netId;
            const isActive = activeNet === segment.netId;
            return (
              <g
                key={`wire-segment-${segment.componentId}`}
                className={`bb-wire-segment${isActive ? " active" : ""}`}
                style={{ opacity: isDim ? 0.18 : 1 }}
                onMouseEnter={() => setHoverNet(segment.netId)}
                onMouseLeave={() => setHoverNet(null)}
                onClick={() => handleVisualNetClick(segment.netId, pinsForNet(segment.netId))}
              >
                <line
                  x1={segment.a.x}
                  y1={segment.a.y}
                  x2={segment.b.x}
                  y2={segment.b.y}
                  className="bb-wire-segment-hit"
                />
                <line
                  x1={segment.a.x}
                  y1={segment.a.y}
                  x2={segment.b.x}
                  y2={segment.b.y}
                  className="bb-wire-segment-line"
                  stroke={segment.color}
                  strokeWidth={isActive ? 4.2 : 3.1}
                />
                <title>{`${segment.componentId} · ${segment.netId}`}</title>
              </g>
            );
          })}

          {/* 2.5: 普通信号网路线。电源/地轨用 strip + Wire 物理线表达，不再画全局 bus。 */}
          {netRoutes.map((route) => {
            const isDim = activeNet !== null && activeNet !== route.netId;
            const isActive = activeNet === route.netId;
            const isHighlightedNet = highlightSets.netIds.has(route.netId);
            return (
              <g
                key={`netroute-${route.netId}`}
                className={`bb-net-route ${isActive ? "active" : ""}${isHighlightedNet ? " highlighted" : ""}`}
                style={{ opacity: isDim ? 0.12 : 1 }}
                onMouseEnter={() => setHoverNet(route.netId)}
                onMouseLeave={() => setHoverNet(null)}
                onClick={() => handleVisualNetClick(route.netId, pinsForNet(route.netId))}
              >
                <path className="bb-net-route-hit" d={route.d} />
                <path className="bb-net-route-halo" d={route.d} />
                <path
                  className="bb-net-route-line"
                  d={route.d}
                  stroke={route.color}
                  strokeWidth={isActive ? 3.1 : isHighlightedNet ? 3.1 : 2.3}
                  strokeOpacity={isActive ? 0.98 : isHighlightedNet ? 0.98 : 0.82}
                />
                {route.points.map((p, index) => (
                  <circle
                    key={`${route.netId}-${index}`}
                    cx={p.x}
                    cy={route.busY}
                    r={isActive ? 3.1 : 2.4}
                    fill="#fff"
                    stroke={route.color}
                    strokeWidth={1.4}
                  />
                ))}
                <g className="bb-net-route-label">
                  {(() => {
                    const assigned = annotationByNetId.get(route.netId);
                    const routeLabel = assigned?.label ? `${route.netId} · ${assigned.label}` : route.netId;
                    return (
                      <>
                        <rect
                          x={route.labelX - 3}
                          y={route.labelY - 9}
                          width={Math.max(30, routeLabel.length * 6.4 + 8)}
                          height={13}
                          rx={3}
                          fill={assigned ? "#ecfdf5" : "#fff"}
                          stroke={route.color}
                          strokeOpacity={0.75}
                        />
                        <text
                          x={route.labelX + 1}
                          y={route.labelY + 1}
                          fill={route.color}
                          className="bb-route-text"
                        >
                          {routeLabel}
                        </text>
                      </>
                    );
                  })()}
                </g>
                <title>{`${route.netId} · ${route.role} · ${route.points.length} connected holes`}</title>
              </g>
            );
          })}

          {/* 3.0 ambiguous 候选孔位（虚线小圈，提示这根脚也可能落到这里） */}
          {Array.from(model.holes.entries()).flatMap(([selectedKey, pins]) => {
            const pos = holePos(selectedKey);
            if (!pos) return [];
            const ambig = pins.find((p) => p.isAmbiguous && p.candidateHoleIds && p.candidateHoleIds.length > 1);
            if (!ambig || !ambig.candidateHoleIds) return [];
            const role = model.netRoles.get(ambig.netId) ?? "SIGNAL";
            const color = getNetColor(ambig.netId, role);
            const isDim = activeNet !== null && activeNet !== ambig.netId;
            return ambig.candidateHoleIds.slice(0, 4).flatMap((candStr, i) => {
              const candAddr = parseHoleId(candStr);
              if (!candAddr) return [];
              const candKey = holeKey(candAddr);
              if (candKey === selectedKey) return [];
              const cp = holePos(candKey);
              if (!cp) return [];
              return [
                <line
                  key={`amb-line-${selectedKey}-${i}`}
                  x1={pos.x}
                  y1={pos.y}
                  x2={cp.x}
                  y2={cp.y}
                  stroke={color}
                  strokeOpacity={isDim ? 0.06 : 0.4}
                  strokeWidth={1}
                  strokeDasharray="2 3"
                />,
                <circle
                  key={`amb-cand-${selectedKey}-${i}`}
                  cx={cp.x}
                  cy={cp.y}
                  r={HOLE_R + 2.5}
                  fill="none"
                  stroke={color}
                  strokeOpacity={isDim ? 0.1 : 0.55}
                  strokeWidth={1.1}
                  strokeDasharray="2 2"
                />,
              ];
            });
          })}

          {/* 3.1 component pair highlight: 悬停一个孔时，高亮同一元件的其它孔位 */}
          {(() => {
            const sourceKey = hover?.sourceHoleKey;
            const source = sourceKey ? holePos(sourceKey) : null;
            if (!source) return null;
            const pairs = pairedHolesForHover();
            if (pairs.length === 0) return null;
            const color = "#0f766e";
            return (
              <g className="bb-comp-pair-layer" pointerEvents="none">
                {pairs.map((pair) => (
                  <line
                    key={`comp-pair-line-${sourceKey}-${pair.key}`}
                    x1={source.x}
                    y1={source.y}
                    x2={pair.x}
                    y2={pair.y}
                    className="bb-comp-pair-line"
                    stroke={color}
                  />
                ))}
                <circle
                  cx={source.x}
                  cy={source.y}
                  r={HOLE_R + 7}
                  className="bb-comp-pair-source"
                  stroke={color}
                />
                {pairs.map((pair) => (
                  <circle
                    key={`comp-pair-ring-${pair.key}`}
                    cx={pair.x}
                    cy={pair.y}
                    r={HOLE_R + 7}
                    className="bb-comp-pair-ring"
                    stroke={color}
                  >
                    <title>
                      {pair.pins.map((pin) => `${pin.componentId}.${pin.pinName}@${pin.holeId}`).join(" / ")}
                    </title>
                  </circle>
                ))}
              </g>
            );
          })()}

          {/* 3. 已用孔（高亮 + 脉冲；可拖拽手工修正） */}
          {Array.from(model.holes.entries()).map(([k, pins]) => {
            // 拖拽中的源孔不画在原位（避免与 ghost 重影）
            if (drag && drag.origHoleKey === k && pins.every((p) => pinKeyOf(p.componentId, p.pinName) === drag.pinKey)) {
              return null;
            }
            const pos = holePos(k);
            if (!pos) return null;
            const netId = pins[0].netId;
            const role = model.netRoles.get(netId) ?? "SIGNAL";
            const color = getNetColor(netId, role);
            const isActive = activeNet === netId;
            const isDim = activeNet !== null && !isActive;
            const isAmbiguous = pins.some((p) => p.isAmbiguous);
            const isCorrected = pins.some((p) => p.userCorrected);
            const assignedPort = annotationByNetId.get(netId);
            const dragPin = pins[0]; // 多 pin 同孔时拖第一根
            const anyPinCompHighlighted = pins.some((p) => highlightSets.compIds.has(p.componentId));
            const isHighlightedHole = highlightSets.holeIds.has(k) || anyPinCompHighlighted || highlightSets.netIds.has(netId);
            return (
              <g
                key={`used-${k}`}
                className={`bb-used${isAmbiguous ? " ambiguous" : ""}${isCorrected ? " corrected" : ""}${isHighlightedHole ? " highlighted" : ""}`}
                style={{ opacity: isDim ? 0.18 : 1 }}
                onMouseEnter={(e) => {
                  const svgRect = (e.currentTarget.ownerSVGElement as SVGSVGElement).getBoundingClientRect();
                  const scale = svgRect.width / BOARD_WIDTH;
                  setHoverNet(netId);
                  setHover({
                    x: svgRect.left + pos.x * scale + 8,
                    y: svgRect.top + pos.y * scale - 8,
                    sourceHoleKey: k,
                    netId,
                    netRole: role,
                    pins,
                  });
                }}
                onMouseLeave={() => {
                  setHover(null);
                  setHoverNet(null);
                }}
                onMouseDown={(e) => {
                  // 仅左键 + 没有修饰键时进入拖拽模式
                  if (e.button !== 0 || e.shiftKey || e.altKey || e.ctrlKey || e.metaKey) return;
                  if (activePortRef && onPortAnnotationChange) return;
                  startDrag(e, dragPin, k);
                }}
                onClick={() => {
                  // 拖拽结束的 click 已经被 mouseup 吞了；这里只处理纯点击
                  if (drag) return;
                  handleVisualNetClick(netId, pins);
                }}
              >
                <circle
                  cx={pos.x}
                  cy={pos.y}
                  r={isHighlightedHole ? USED_GLOW + 4 : USED_GLOW}
                  fill={color}
                  fillOpacity={isActive ? 0.32 : isHighlightedHole ? 0.45 : 0.18}
                  className="bb-pulse"
                />
                {isAmbiguous ? (
                  <circle
                    cx={pos.x}
                    cy={pos.y}
                    r={HOLE_R + 4}
                    fill="none"
                    stroke="#f59e0b"
                    strokeWidth={1.4}
                    strokeDasharray="3 2"
                    className="bb-ambig-ring"
                  />
                ) : null}
                {isCorrected ? (
                  <circle
                    cx={pos.x}
                    cy={pos.y}
                    r={HOLE_R + 5}
                    fill="none"
                    stroke="#10b981"
                    strokeWidth={1.4}
                    strokeDasharray="2 2"
                  />
                ) : null}
                {assignedPort ? (
                  <circle
                    cx={pos.x}
                    cy={pos.y}
                    r={HOLE_R + 7}
                    fill="none"
                    stroke="#059669"
                    strokeWidth={1.8}
                  />
                ) : null}
                <circle
                  cx={pos.x}
                  cy={pos.y}
                  r={HOLE_R + 1}
                  fill={color}
                  stroke={isCorrected ? "#10b981" : isAmbiguous ? "#f59e0b" : isHighlightedHole ? "#be3144" : "#fff"}
                  strokeWidth={isCorrected || isAmbiguous || isHighlightedHole ? 1.8 : 1.4}
                />
                {assignedPort?.label ? (
                  <text
                    x={pos.x}
                    y={pos.y - 11}
                    textAnchor="middle"
                    className="bb-port-label"
                  >
                    {assignedPort.label}
                  </text>
                ) : null}
              </g>
            );
          })}

          {/* 拖拽 ghost：原位淡圈 + 跟随光标的虚拟孔 + 候选高亮 */}
          {drag ? (() => {
            const orig = holePos(drag.origHoleKey);
            const color = getNetColor(drag.netId, drag.netRole);
            const target = nearestHoleKey(drag.cursorBoardX, drag.cursorBoardY, COL_STEP * 1.2);
            const targetPos = target ? holePos(target) : null;
            return (
              <g key="drag-ghost" pointerEvents="none">
                {orig ? (
                  <circle
                    cx={orig.x}
                    cy={orig.y}
                    r={HOLE_R + 1}
                    fill="none"
                    stroke={color}
                    strokeOpacity={0.45}
                    strokeWidth={1.4}
                    strokeDasharray="3 2"
                  />
                ) : null}
                {orig ? (
                  <line
                    x1={orig.x}
                    y1={orig.y}
                    x2={drag.cursorBoardX}
                    y2={drag.cursorBoardY}
                    stroke={color}
                    strokeOpacity={0.5}
                    strokeWidth={1.6}
                    strokeDasharray="4 3"
                  />
                ) : null}
                {targetPos ? (
                  <>
                    <circle
                      cx={targetPos.x}
                      cy={targetPos.y}
                      r={HOLE_R + 5}
                      fill="none"
                      stroke="#10b981"
                      strokeWidth={1.6}
                      strokeDasharray="2 2"
                      className="bb-ambig-ring"
                    />
                    <circle
                      cx={targetPos.x}
                      cy={targetPos.y}
                      r={HOLE_R + 1}
                      fill={color}
                      fillOpacity={0.85}
                      stroke="#10b981"
                      strokeWidth={1.6}
                    />
                  </>
                ) : (
                  <circle
                    cx={drag.cursorBoardX}
                    cy={drag.cursorBoardY}
                    r={HOLE_R + 1}
                    fill={color}
                    fillOpacity={0.4}
                    stroke="#fff"
                    strokeWidth={1.2}
                  />
                )}
              </g>
            );
          })() : null}

          {/* 4. 标签层 (顶层): 列号 / 行字母 / 电源轨标签 / 元件标签 */}
          {Array.from({ length: BREADBOARD_COLS }, (_, i) => i + 1).map((col) =>
            col % 5 === 0 || col === 1 ? (
              <text
                key={`colnum-${col}`}
                x={colX(col)}
                y={PAD_Y - 6}
                textAnchor="middle"
                className="bb-text"
              >
                {col}
              </text>
            ) : null,
          )}
          {/* 行字母双侧 */}
          {[...TOP_LETTERS, ...BOT_LETTERS].flatMap((l) => [
            <text
              key={`rowletter-L-${l}`}
              x={PAD_X - 14}
              y={matrixY(l) + 3}
              textAnchor="middle"
              className="bb-text"
            >
              {l}
            </text>,
            <text
              key={`rowletter-R-${l}`}
              x={BOARD_WIDTH - PAD_X + 14}
              y={matrixY(l) + 3}
              textAnchor="middle"
              className="bb-text"
            >
              {l}
            </text>,
          ])}
          {/* 电源轨标签：左右两端各一份 (× 4 轨 = 8 个) */}
          {(["top_plus", "top_minus", "bot_plus", "bot_minus"] as RailKind[]).flatMap((rail) => [
            <text
              key={`rail-label-L-${rail}`}
              x={PAD_X - 14}
              y={railY(rail) + 3}
              textAnchor="middle"
              className="bb-text rail"
              fill={RAIL_TINT[rail]}
            >
              {RAIL_LABELS[rail]}
            </text>,
            <text
              key={`rail-label-R-${rail}`}
              x={BOARD_WIDTH - PAD_X + 14}
              y={railY(rail) + 3}
              textAnchor="middle"
              className="bb-text rail"
              fill={RAIL_TINT[rail]}
            >
              {RAIL_LABELS[rail]}
            </text>,
          ])}
          {/* 元件标签：在元件锚点上方显示 component_id (避开聚焦淡化时也能看到) */}
          {Array.from(model.componentHoles.keys()).map((cid) => {
            const a = componentAnchor(cid);
            if (!a) return null;
            const compType = model.componentTypes.get(cid) ?? "";
            const isHighlightedComp = highlightSets.compIds.has(cid);
            return (
              <g key={`complabel-${cid}`} className={`bb-component-label${isHighlightedComp ? " highlighted" : ""}`}>
                <rect
                  x={a.x - 22}
                  y={a.y - 28}
                  width={44}
                  height={14}
                  rx={3}
                  fill={isHighlightedComp ? "#be3144" : "#1f2937"}
                  fillOpacity={0.78}
                />
                <text
                  x={a.x}
                  y={a.y - 18}
                  textAnchor="middle"
                  className="bb-text comp"
                >
                  {cid}
                </text>
                {compType ? (
                  <title>{`${cid} · ${compType}`}</title>
                ) : null}
              </g>
            );
          })}
        </svg>

        {hover ? (
          <div className="bb-tooltip" style={{ left: hover.x, top: hover.y }}>
            <div className="bb-tooltip-net">
              <span
                className="bb-tooltip-dot"
                style={{ background: getNetColor(hover.netId, hover.netRole) }}
              />
              <strong>{hover.netId}</strong>
              {hover.netRole !== "SIGNAL" ? <span className="bb-role-tag">{hover.netRole}</span> : null}
            </div>
            <ul>
              {hover.pins.map((p, i) => (
                <li key={i}>
                  <span className="bb-tooltip-comp">{p.componentId}</span>
                  <span className="bb-tooltip-pin">
                    {displayPolarity(p)}
                  </span>
                  <span className="bb-tooltip-hole">@{p.holeId}</span>
                </li>
              ))}
            </ul>
            {hover.pins.some((p) => p.isAmbiguous) ? (
              <div className="bb-tooltip-ambig">
                <div className="bb-tooltip-ambig-title">⚠ 该孔位吸附存在歧义</div>
                {hover.pins
                  .filter((p) => p.isAmbiguous)
                  .map((p, i) => (
                    <div key={i} className="bb-tooltip-ambig-row">
                      {p.candidateHoleIds && p.candidateHoleIds.length > 1 ? (
                        <span className="bb-tooltip-ambig-cands">
                          候选: {p.candidateHoleIds.slice(0, 4).join(" / ")}
                        </span>
                      ) : null}
                      {p.ambiguityReasons && p.ambiguityReasons.length > 0 ? (
                        <span className="bb-tooltip-ambig-reasons">
                          原因: {p.ambiguityReasons.join(", ")}
                        </span>
                      ) : null}
                    </div>
                  ))}
              </div>
            ) : null}
          </div>
        ) : null}
      </div>

      {model.unresolvedPins.length > 0 ? (
        <div className="bb-warning-panel" role="status">
          <strong>有 {model.unresolvedPins.length} 个 pin 未能映射到前端孔位</strong>
          <ul>
            {model.unresolvedPins.slice(0, 6).map((pin, index) => (
              <li key={`${pin.componentId}-${pin.pinName}-${index}`}>
                <span>{pin.componentId}</span>
                <span>{pin.pinName}</span>
                <span>{pin.rawHoleId ?? "-"}</span>
                <em>{pin.reason}</em>
              </li>
            ))}
          </ul>
          {model.unresolvedPins.length > 6 ? (
            <p>另有 {model.unresolvedPins.length - 6} 个未显示。</p>
          ) : null}
        </div>
      ) : null}

      {/* Pin/hole quick semantic tagging. Net-level tagging above is the primary workflow. */}
      {allPins.length > 0 ? (
        <div className="bb-pin-role-panel">
          <div className="panel-heading">
            <h2>Pin 快捷标注</h2>
            <span>
              {netRoleAssignments.size > 0 ? (
                <span className="manual-role-summary">已标注 {netRoleAssignments.size} 个网络</span>
              ) : (
                <span className="manual-role-summary">未标注</span>
              )}
            </span>
          </div>
          <p className="muted">
            端口输入/输出已改为在上方可视化图中点选；这里仅保留三极管 E/B/C 与高级网络角色覆盖。
          </p>
          <div className="bb-pin-role-table-wrap">
            <table className="bb-pin-role-table">
              <thead>
                <tr>
                  <th>元件</th>
                  <th>引脚</th>
                  <th>孔位</th>
                  <th>网络</th>
                  <th>极性</th>
                  <th>角色</th>
                </tr>
              </thead>
              <tbody>
                {allPins.map((pin) => {
                  const key = `${pin.componentId}.${pin.pinName}`;
                  return (
                    <tr key={key}>
                      <td>{pin.componentId}</td>
                      <td>{displayPolarity(pin)}</td>
                      <td>{pin.holeId}</td>
                      <td className="net-cell">{pin.netId}</td>
                      <td>
                        {pin.componentType === "Transistor" ? (
                          <select
                            className="net-role-select"
                            value={pinPolarityAssignments.get(key) ?? ""}
                            onChange={(e) => handlePolarityChange(pin, e.target.value)}
                          >
                            <option value="">自动</option>
                            <option value="E">E</option>
                            <option value="B">B</option>
                            <option value="C">C</option>
                          </select>
                        ) : (
                          <span className="muted">-</span>
                        )}
                      </td>
                      <td>
                        <button
                          type="button"
                          className="bb-reset-btn"
                          onClick={() => setSelectedNet((cur) => (cur === pin.netId ? null : pin.netId))}
                        >
                          聚焦网络
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}

      {/* 手动修正提交区域 */}
      <div className="manual-correction-actions">
        <button
          type="button"
          className="run-button correction-compare-button"
          onClick={onApplyCorrections}
          disabled={(corrections.size === 0 && netRoleAssignments.size === 0 && pinPolarityAssignments.size === 0) || isApplyingCorrections}
          title={
            selectedReferenceId
              ? "将手工修正提交给后端，重算拓扑并与逻辑参考电路比较"
              : "将手工修正提交给后端并重算拓扑"
          }
        >
          {isApplyingCorrections
            ? "正在重算..."
            : selectedReferenceId
              ? "确认修正并与逻辑参考电路比较"
              : "确认修正并重算网表"}
        </button>
        <div className="manual-correction-meta">
          {corrections.size > 0 || netRoleAssignments.size > 0 || pinPolarityAssignments.size > 0 ? (
            <div className="manual-correction-counts">
              {corrections.size > 0 ? (
                <span>当前 netlist 修正 {corrections.size} 项</span>
              ) : null}
              {netRoleAssignments.size > 0 ? (
                <span>端口语义标注 {netRoleAssignments.size} 项</span>
              ) : null}
              {pinPolarityAssignments.size > 0 ? (
                <span>引脚极性 {pinPolarityAssignments.size} 项</span>
              ) : null}
            </div>
          ) : null}
          <div className="manual-correction-reset-btns">
            {corrections.size > 0 ? (
              <button type="button" className="bb-reset-btn" onClick={onResetCorrections}>
                ↺ 重置当前 netlist 修正
              </button>
            ) : null}
            {netRoleAssignments.size > 0 && onResetNetRoles ? (
              <button type="button" className="bb-reset-btn" onClick={onResetNetRoles}>
                ↺ 重置端口语义标注
              </button>
            ) : null}
            {pinPolarityAssignments.size > 0 && onResetPinPolarities ? (
              <button type="button" className="bb-reset-btn" onClick={onResetPinPolarities}>
                ↺ 重置引脚极性
              </button>
            ) : null}
          </div>
        </div>
        <p className="muted">
          手动孔位修正只用于修正当前识别结果，不代表参考电路固定孔位。
          端口语义标注会写到该 pin 所在的 electrical_net_id，并携带 role 与 role_label 交给后端做拓扑比较。
          三极管 E/B/C 用于功能引脚匹配，不是孔位参考匹配。
        </p>
      </div>

      {/* 图例 / net 索引 */}
      <div className="bb-legend">
        {usedNetIds.map((netId) => {
          const role = model.netRoles.get(netId) ?? "SIGNAL";
          const color = getNetColor(netId, role);
          const compCount = model.netComponents.get(netId)?.size ?? 0;
          const holeCount = model.netHoles.get(netId)?.length ?? 0;
          const isActive = activeNet === netId;
          return (
            <button
              key={netId}
              type="button"
              className={`bb-legend-item ${isActive ? "active" : ""}`}
              onClick={() => setSelectedNet((cur) => (cur === netId ? null : netId))}
              onMouseEnter={() => setHoverNet(netId)}
              onMouseLeave={() => setHoverNet(null)}
            >
              <span className="bb-legend-dot" style={{ background: color }} />
              <span className="bb-legend-name">{netId}</span>
              {role !== "SIGNAL" ? <span className={`bb-role-tag ${role.toLowerCase()}`}>{role}</span> : null}
              <span className="bb-legend-meta">
                {compCount} 元件 · {holeCount} 孔
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}
