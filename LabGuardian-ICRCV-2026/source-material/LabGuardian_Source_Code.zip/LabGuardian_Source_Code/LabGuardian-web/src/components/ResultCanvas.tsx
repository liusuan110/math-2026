import { useEffect, useRef, useState } from "react";
import type {
  CircuitAnalysisResult,
  EvidenceRef,
  Pin,
  PipelineComponent,
  PipelineResult,
  PortVisualizationResult,
} from "../types/pipeline";
import type { CanvasMode } from "../types/ui";
import { isIcLikeComponent, normalizePackageType } from "../utils/icAnnotations";
import { getDetections, getMappedComponents, getPinComponents } from "../utils/pipeline";

type Props = {
  imageUrl: string;
  result: PipelineResult | CircuitAnalysisResult | PortVisualizationResult | null;
  mode: CanvasMode;
  highlightTargets?: EvidenceRef[];
};

function drawLabel(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, color: string, scale = 1) {
  ctx.save();
  ctx.font = `${14 * scale}px Inter, sans-serif`;
  const padding = 4 * scale;
  const metrics = ctx.measureText(text);
  const width = metrics.width + padding * 2;
  const height = 18 * scale;
  const safeX = Math.max(0, Math.min(x, ctx.canvas.width - width));
  const safeY = Math.max(height, y);
  ctx.fillStyle = color;
  ctx.fillRect(safeX, safeY - height, width, height);
  ctx.fillStyle = "#ffffff";
  ctx.fillText(text, safeX + padding, safeY - 5 * scale);
  ctx.restore();
}

function drawBox(ctx: CanvasRenderingContext2D, bbox: number[], label: string, color: string, scale = 1) {
  if (bbox.length < 4) return;
  const [x1, y1, x2, y2] = bbox;
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = 2 * scale;
  ctx.strokeRect(x1, y1, x2 - x1, y2 - y1);
  drawLabel(ctx, label, x1, y1 - 6 * scale, color, scale);
  ctx.restore();
}

function topPoint(component: PipelineComponent, pinIndex: number) {
  const pin = component.pins?.[pinIndex];
  if (!pin) return null;
  const top = pin.keypoints_by_view?.top;
  if (top) return top;
  if (typeof pin.x_image === "number" && typeof pin.y_image === "number") {
    return [pin.x_image, pin.y_image];
  }
  return null;
}

function drawPin(
  ctx: CanvasRenderingContext2D,
  point: number[] | null | undefined,
  label: string,
  color: string,
  showLabel: boolean,
  labelOffset: { x: number; y: number } = { x: 8, y: -6 },
  scale = 1,
) {
  if (!point || point.length < 2) return;
  const [x, y] = point;
  ctx.save();
  ctx.fillStyle = color;
  ctx.strokeStyle = "#1b2522";
  ctx.lineWidth = 1.5 * scale;
  ctx.beginPath();
  ctx.arc(x, y, 5 * scale, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  if (showLabel) {
    drawLabel(ctx, label, x + labelOffset.x * scale, y + labelOffset.y * scale, "#31544e", scale);
  }
  ctx.restore();
}

function pinLabelOffset(component: PipelineComponent, pinIndex: number): { x: number; y: number } {
  if ((component.component_type ?? "").toLowerCase() !== "potentiometer") {
    return { x: 8, y: -6 };
  }
  const pins = component.pins ?? [];
  const points = pins
    .map((_, index) => topPoint(component, index))
    .filter((point): point is number[] => Boolean(point && point.length >= 2));
  if (points.length < 2) return { x: 8, y: -6 };
  const xs = points.map((point) => point[0]);
  const ys = points.map((point) => point[1]);
  const spreadX = Math.max(...xs) - Math.min(...xs);
  const spreadY = Math.max(...ys) - Math.min(...ys);
  const slot = pinIndex - 1;
  if (spreadY >= spreadX) {
    return { x: 10 + Math.abs(slot) * 10, y: slot * 18 - 6 };
  }
  return { x: 10, y: slot * 18 - 6 };
}

function isHighlighted(
  componentId: string | undefined,
  pinName: string | undefined,
  holeId: string | undefined,
  electricalNetId: string | undefined,
  targets: EvidenceRef[],
): boolean {
  for (const t of targets) {
    switch (t.type) {
      case "component":
        if (componentId && t.component_id === componentId) return true;
        break;
      case "pin":
        if (componentId && t.component_id === componentId && (!t.pin_name || t.pin_name === pinName)) return true;
        if (holeId && t.hole_id === holeId) return true;
        break;
      case "net":
        if (electricalNetId && t.electrical_net_id === electricalNetId) return true;
        break;
      case "reference_component":
        break;
    }
  }
  return false;
}

function drawComponents(
  ctx: CanvasRenderingContext2D,
  components: PipelineComponent[],
  mode: CanvasMode,
  showComponentBoxes: boolean,
  showPinLabels: boolean,
  targets: EvidenceRef[],
  scale = 1,
) {
  components.forEach((component, componentIndex) => {
    const baseColor = ["#14796b", "#2563eb", "#b45309", "#7c3aed"][componentIndex % 4];
    const compHighlighted = isHighlighted(component.component_id, undefined, undefined, undefined, targets);
    const color = compHighlighted ? "#be3144" : baseColor;
    if (showComponentBoxes && component.bbox) {
      drawBox(
        ctx,
        component.bbox,
        `${component.component_id ?? ""} ${component.component_type ?? "UNKNOWN"}`.trim(),
        color,
        scale,
      );
    }
    component.pins?.forEach((pin, pinIndex) => {
      const point = topPoint(component, pinIndex);
      const baseLabel =
        pin.polarity_role && pin.polarity_role !== "UNKNOWN"
          ? pin.polarity_role
          : pin.polarity_candidate_role && pin.polarity_candidate_role !== "UNKNOWN"
            ? pin.polarity_candidate_role
            : pin.pin_display_name ?? pin.pin_name ?? `pin${pinIndex + 1}`;
      const suffix =
        mode === "mapping" ? ` ${pin.hole_id ?? "-"} ${pin.electrical_node_id ?? ""}` : "";
      const pinHighlighted = isHighlighted(component.component_id, pin.pin_name, pin.hole_id, pin.electrical_net_id, targets);
      drawPin(
        ctx,
        point,
        `${baseLabel}${suffix}`,
        pinHighlighted ? "#ff5722" : "#ffd166",
        showPinLabels,
        pinLabelOffset(component, pinIndex),
        scale,
      );
    });
  });
}

function getExpectedPinCount(packageType: string | undefined): number | null {
  const normalized = normalizePackageType(packageType);
  if (normalized === "dip8") return 8;
  if (normalized === "dip14") return 14;
  return null;
}

function displayPinName(pin: Pin | undefined, fallback: string): string {
  if (!pin) return fallback;
  return pin.polarity_role && pin.polarity_role !== "UNKNOWN"
    ? pin.polarity_role
    : pin.polarity_candidate_role && pin.polarity_candidate_role !== "UNKNOWN"
      ? pin.polarity_candidate_role
      : pin.pin_display_name || pin.pin_name || fallback;
}

function pinSource(pin: Pin | undefined): string {
  return pin?.source ?? pin?.source_by_view?.top ?? "-";
}

function pinCoordinate(pin: Pin | undefined): string {
  if (!pin) return "-";
  const point = pin.keypoints_by_view?.top;
  if (point && point.length >= 2) {
    return `${Math.round(point[0])}, ${Math.round(point[1])}`;
  }
  if (typeof pin.x_image === "number" && typeof pin.y_image === "number") {
    return `${Math.round(pin.x_image)}, ${Math.round(pin.y_image)}`;
  }
  return "-";
}

function normalizedPinKey(pin: Pin): string {
  return (pin.pin_name ?? pin.pin_display_name ?? "").trim().toLowerCase();
}

function getDisplayPins(component: PipelineComponent): Array<{ label: string; pin?: Pin }> {
  const pins = component.pins ?? [];
  const expectedCount = getExpectedPinCount(component.package_type);
  if (!expectedCount || !isIcLikeComponent(component)) {
    return pins.map((pin, index) => ({ label: displayPinName(pin, `pin${index + 1}`), pin }));
  }

  return Array.from({ length: expectedCount }, (_, index) => {
    const label = `pin${index + 1}`;
    const pin =
      pins.find((candidate) => normalizedPinKey(candidate) === label) ??
      pins.find((candidate) => candidate.pin_id === index + 1);
    return { label, pin };
  });
}

function PinCoordinateView({ result }: { result: Props["result"] }) {
  const components = getMappedComponents(result);

  if (components.length === 0) {
    return (
      <section className="mapping-panel">
        <div className="panel-heading">
          <h2>孔位映射</h2>
        </div>
        <p className="muted">等待 S2 孔位映射阶段完成...</p>
      </section>
    );
  }

  return (
    <section className="mapping-panel">
      <div className="panel-heading">
        <h2>元件引脚与面包板坐标</h2>
        <span>{components.length} 个元件</span>
      </div>

      <div className="pin-coordinate-list">
        {components.map((comp) => (
          <div key={comp.component_id} className="pin-coordinate-card">
            <div className="component-header">
              <span className="component-id">{comp.component_id}</span>
              <span className="component-type">{comp.component_type}</span>
              {comp.package_type ? (
                <span className="component-package">{normalizePackageType(comp.package_type)}</span>
              ) : null}
            </div>
            {isIcLikeComponent(comp) && !getExpectedPinCount(comp.package_type) ? (
              <p className="ic-package-warning">封装类型不确定，请检查芯片检测框</p>
            ) : null}
            <div className="pins-container">
              {getDisplayPins(comp).map(({ label, pin }, index) => (
                <div key={`${comp.component_id}-${label}-${index}`} className="pin-item">
                  <span className="pin-name">{label}</span>
                  <span className="arrow">→</span>
                  <span className="hole-coord">{pin?.hole_id || "-"}</span>
                  {pin?.electrical_node_id ? (
                    <>
                      <span className="arrow">→</span>
                      <span className="net-id">{pin.electrical_node_id}</span>
                    </>
                  ) : null}
                  <span className="pin-source">source={pinSource(pin)}</span>
                  <span className="pin-point">{pinCoordinate(pin)}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export function ResultCanvas({ imageUrl, result, mode, highlightTargets = [] }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [showPinModeBoxes, setShowPinModeBoxes] = useState(true);
  const [showPinLabels, setShowPinLabels] = useState(true);

  useEffect(() => {
    if (!imageUrl) {
      setImage(null);
      return;
    }
    let cancelled = false;
    const nextImage = new Image();
    nextImage.onload = () => {
      if (!cancelled) setImage(nextImage);
    };
    nextImage.src = imageUrl;
    return () => {
      cancelled = true;
      nextImage.onload = null;
    };
  }, [imageUrl]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !image) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(image, 0, 0);

    if (!result) return;

    const scale = Math.max(0.5, Math.min(2.0, image.naturalWidth / 1920));

    if (mode === "detect") {
      getDetections(result).forEach((detection, index) => {
        if (!detection.bbox) return;
        const highlighted = isHighlighted(detection.component_id, undefined, undefined, undefined, highlightTargets);
        const label = `${detection.component_id ?? `D${index + 1}`} ${
          detection.component_type ?? detection.class_name ?? "UNKNOWN"
        }`;
        drawBox(ctx, detection.bbox, label, highlighted ? "#be3144" : "#14796b", scale);
      });
    }

    if (mode === "pins") {
      drawComponents(ctx, getPinComponents(result), mode, showPinModeBoxes, showPinLabels, highlightTargets, scale);
    }

    if (mode === "mapping") {
      drawComponents(ctx, getMappedComponents(result), mode, true, showPinLabels, highlightTargets, scale);
    }
  }, [image, mode, result, showPinModeBoxes, showPinLabels, highlightTargets]);

  if (mode === "mapping") {
    return <PinCoordinateView result={result} />;
  }

  if (!imageUrl) {
    return <div className="empty-stage">上传图片后显示检测框、引脚点。</div>;
  }

  return (
    <>
      {mode === "pins" ? (
        <div className="canvas-tools">
          <button
            type="button"
            className="canvas-toggle-btn"
            onClick={() => setShowPinModeBoxes((current) => !current)}
          >
            {showPinModeBoxes ? "只看引脚" : "显示元件框"}
          </button>
          <button
            type="button"
            className="canvas-toggle-btn"
            onClick={() => setShowPinLabels((current) => !current)}
          >
            {showPinLabels ? "隐藏引脚名" : "显示引脚名"}
          </button>
        </div>
      ) : null}
      <canvas ref={canvasRef} className="result-canvas" />
    </>
  );
}
