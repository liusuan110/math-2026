export type JobStatus = "pending" | "running" | "completed" | "failed";

export type PipelineStageName =
  | "detect"
  | "pin_detect"
  | "mapping"
  | "topology"
  | "validate"
  | "semantic_analysis";

export type RiskLevel = "safe" | "warning" | "danger" | string;

export type RailAssignments = {
  top_plus: string;
  top_minus: string;
  bot_plus: string;
  bot_minus: string;
};

export type ReferenceSummary = {
  reference_id: string;
  name: string;
  description?: string;
  format: "logical_reference_v1" | string;
  component_count: number;
  net_count: number;
};

export type LogicalReferenceNet = {
  net: string;
  role?: "input" | "output" | "power" | "ground" | "signal" | string;
  label?: string;
  role_label?: string;
};

export type LogicalReferenceComponent = {
  ref_id: string;
  type: string;
  pins: Array<{ pin: string; net: string }>;
  value?: string;
  subtype?: string;
  description?: string;
};

export type LogicalReference = {
  format: "logical_reference_v1";
  reference_id: string;
  name?: string;
  description?: string;
  nets: LogicalReferenceNet[];
  components: LogicalReferenceComponent[];
  symmetry_groups?: unknown[];
};

export type PinSelector = {
  hole_id?: string | null;
  component_id?: string | null;
  pin_name?: string | null;
  electrical_net_id?: string | null;
  electrical_node_id?: string | null;
  x_image?: number | null;
  y_image?: number | null;
};

export type PortAnnotation = {
  role: "input" | "output";
  target: PinSelector;
  label?: string | null;
  source?: "port_annotation";
};

export type IcNotchDirection = "left" | "right" | "top" | "bottom" | "unknown";

export type IcAnnotation = {
  component_id: string;
  notch_direction: IcNotchDirection;
  package_type?: string;
};

export type PipelineRequest = {
  station_id: string;
  images_b64: string[];
  conf: number;
  iou: number;
  imgsz: number;
  reference_id?: string | null;
  reference_circuit?: Record<string, unknown> | null;
  rail_assignments?: RailAssignments;
  port_annotations?: PortAnnotation[];
  net_role_assignments?: ManualNetRoleAssignment[];
  ic_annotations?: IcAnnotation[];
};

export type ManualCorrectionPatch = {
  component_id: string;
  pin_name: string;
  from_hole_id: string;
  to_hole_id: string;
  source: "manual_drag";
};

export type ManualNetRole = "input" | "output" | "power" | "ground" | "signal";

export type ManualNetRoleAssignment = {
  role: ManualNetRole;
  role_label?: string | null;
  source?: "manual_netlist_select";
  component_id?: string | null;
  pin_name?: string | null;
  hole_id?: string | null;
  electrical_node_id?: string | null;
  electrical_net_id?: string | null;
};

export type ManualPinPolarityAssignment = {
  component_id: string;
  pin_name: string;
  polarity: "E" | "B" | "C";
  source?: "manual_pin_polarity_select";
};

export type CorrectedRecomputeRequest = {
  station_id: string;
  job_id?: string | null;
  components: PipelineComponent[];
  corrections: ManualCorrectionPatch[];
  rail_assignments?: RailAssignments;
  reference_id?: string | null;
  reference_circuit?: Record<string, unknown> | null;
  port_annotations?: PortAnnotation[];
  net_role_assignments?: ManualNetRoleAssignment[];
  pin_polarity_assignments?: ManualPinPolarityAssignment[];
  ic_annotations?: IcAnnotation[];
};

export type Detection = {
  component_id?: string;
  class_name?: string;
  component_type?: string;
  package_type?: string;
  confidence?: number;
  bbox?: number[];
  orientation?: number;
  view_id?: string;
  source?: string;
};

export type Pin = {
  pin_id?: number;
  pin_name?: string;
  pin_display_name?: string;
  polarity_role?: string;
  polarity_candidate_role?: string;
  keypoints_by_view?: Record<string, number[] | null>;
  confidence?: number;
  source?: string;
  source_by_view?: Record<string, string>;
  logic_loc?: string;
  hole_id?: string;
  electrical_node_id?: string;
  electrical_net_id?: string;
  x_image?: number;
  y_image?: number;
  x_warp?: number;
  y_warp?: number;
  candidate_hole_ids?: string[];
  candidate_node_ids?: string[];
  is_ambiguous?: boolean;
  ambiguity_reasons?: string[];
};

export type PipelineComponent = {
  component_id?: string;
  component_type?: string;
  class_name?: string;
  package_type?: string;
  bbox?: number[];
  confidence?: number;
  orientation?: number;
  pins?: Pin[];
  /**
   * IC 子型号 (UA741 / LM358 / NE555 ...)，由后端
   * `apply_reference_ic_subtypes` 根据选定的参考电路自动绑定，
   * 或由 vision pipeline 的 OCR / 库匹配设置。
   *
   * Source 信息见 `PipelineResult.runtime_metadata.reference_ic_subtypes_applied[]`。
   */
  part_subtype?: string;
  metadata?: Record<string, unknown>;
};

/**
 * `runtime_metadata.reference_ic_subtypes_applied[]` 中的一条记录。
 * 后端在 `apply_reference_ic_subtypes` 自动绑定 IC 型号后写入，用于
 * 前端区分"由参考自动绑定" vs "vision 直出" vs "用户手动覆盖"。
 */
export type ReferenceIcSubtypeRecord = {
  component_id: string;
  part_subtype: string;
  source: "reference_circuit" | string;
  matched_by: "component_id" | "single_reference_ic" | string;
};

export type NetlistV2 = {
  nets?: Array<{
    net_id?: string;
    electrical_net_id?: string;
    nodes?: string[];
    member_node_ids?: string[];
    member_hole_ids?: string[];
    power_role?: string;
    role?: string;
    role_label?: string;
    canonical_name?: string;
    pins?: Array<Record<string, unknown>>;
    [key: string]: unknown;
  }>;
  components?: Array<Record<string, unknown>>;
  [key: string]: unknown;
};

export type EvidenceRef =
  | { type: "component"; component_id: string }
  | { type: "pin"; component_id: string; pin_name: string; hole_id?: string }
  | { type: "net"; electrical_net_id: string }
  | { type: "reference_component"; component_id: string };

export type ComparisonReportItem = {
  error_code: string;
  error_family?: string;
  severity?: "fatal" | "error" | "warning" | "info" | string;
  title?: string;
  message?: string;
  expected?: unknown;
  actual?: unknown;
  component_ref?: unknown;
  component_actual?: unknown;
  evidence_refs?: EvidenceRef[];
  suggested_action?: string;
};

export type InferredNetRole = {
  reference_net?: string;
  current_net?: string;
  role?: string;
  role_label?: string;
  source?: string;
};

export type AutoSymmetryGroup = {
  mode?: string;
  nets?: string[][];
};

export type PortAnnotationApplied = {
  role?: string;
  role_label?: string;
  electrical_net_id?: string;
  source?: string;
  resolved_by?: string;
  hole_id?: string;
  component_id?: string;
  pin_name?: string;
};

export type GnnCandidate = {
  net: string;
  p_connect: number;
  rank: number;
  /** Human-readable label such as "GND (地)" or "VOUT (输出)". When the
   *  rule↔cur alignment was successful, this is set by the backend
   *  `gnn_display` enricher. Falls back to the raw `net` id otherwise. */
  net_display?: string;
};

export type GnnSuggestedTarget = {
  port: string;
  reason: "likely_wrong" | "floating_required" | string;
  current_nets: string[];
  top_p_connect: number;
  candidates: GnnCandidate[];
  /** "U1 · pin2 (反相输入)" — set when ref↔cur alignment succeeded. */
  port_display?: string;
  /** Parallel array to `current_nets`, with human-readable labels. */
  current_nets_display?: string[];
};

export type GnnEdgePrediction = {
  edge: [string, string];
  p_correct: number;
  verdict: "ok" | "likely_wrong" | string;
  edge_display?: [string, string];
};

export type GnnHotspot = {
  node: string;
  score: number;
  hint?: string;
  node_display?: string;
};

export type GnnAdvice = {
  enabled?: boolean;
  model_version?: string;
  graph_similarity?: number;
  graph_similarity_confidence?: number;
  progress_score?: number | null;
  n_edges_scored?: number;
  n_suggestion_candidates_scored?: number;
  inference_ms?: number;
  edge_predictions?: GnnEdgePrediction[];
  hotspots?: GnnHotspot[];
  suggested_targets?: GnnSuggestedTarget[];
  predicted_error_types?: unknown[];
  component_mapping_topk?: Record<string, unknown[]>;
  net_mapping_topk?: Record<string, unknown[]>;
  disagreement_with_rule?: boolean;
};

export type ComparisonReport = {
  version?: string;
  summary?: {
    comparison_mode?: string;
    logic_correct?: boolean;
    similarity?: number;
    reference_id?: string;
    reference_name?: string;
    total_item_count?: number;
    ignore_component_id?: boolean;
    ignore_hole_id?: boolean;
    ignore_passive_pin_order?: boolean;
    ignore_polarity?: boolean;
    allow_extra_wires?: boolean;
    match_type?: string;
    progress?: number;
    strict_functional_pin_roles?: boolean;
    equivalence_rule?: string;
    role_inference_applied?: boolean;
    inferred_net_roles?: InferredNetRole[];
    auto_symmetry_groups?: AutoSymmetryGroup[];
    port_annotations_applied?: PortAnnotationApplied[];
    ref_to_current_component_mapping?: Record<string, string>;
    ref_to_current_net_mapping?: Record<string, string>;
    gnn?: GnnAdvice;
    /**
     * Set by `app/domain/compare/orchestrator.py:_maybe_attach_gnn_advice`
     * when the advisor silently sits out the call. Mutually exclusive
     * with `gnn`. See backend docstring for the five reason codes.
     */
    gnn_disabled_reason?:
      | "runtime_unavailable"
      | "checkpoint_missing"
      | "tiny_circuit"
      | "trigger_predicate_skipped"
      | "model_failed"
      | string;
  };
  ref_to_current_component_mapping?: Record<string, string>;
  ref_to_current_net_mapping?: Record<string, string>;
  items?: ComparisonReportItem[];
};

export type StageData = {
  interface_version?: string;
  detector_backend?: string;
  pin_detector_backend?: string;
  pin_detector_mode?: string;
  detections?: Detection[];
  components?: PipelineComponent[];
  calibration?: Record<string, unknown>;
  netlist_v2?: NetlistV2;
  topology_graph?: Record<string, unknown>;
  circuit_description?: string;
  is_correct?: boolean;
  diagnosis?: string;
  risk_level?: RiskLevel;
  similarity?: number;
  progress?: number;
  diagnostics?: string[];
  comparison_report?: Record<string, unknown>;
  risk_reasons?: string[];
  details?: Record<string, unknown>;
  circuit_type_guess?: Record<string, unknown>;
  recognized_roles?: Record<string, unknown>;
  matched_template?: Record<string, unknown>;
  wiring_errors?: Array<Record<string, unknown>>;
  suggested_pin_moves?: Array<Record<string, unknown>>;
  student_hint?: string;
  [key: string]: unknown;
};

export type StageResult = {
  stage: PipelineStageName;
  status: JobStatus;
  duration_ms: number;
  data: StageData;
  errors: string[];
};

export type PipelineResult = {
  job_id: string;
  station_id: string;
  status: JobStatus;
  stages: StageResult[];
  total_duration_ms: number;
  component_count: number;
  net_count: number;
  progress: number;
  similarity: number;
  diagnostics: string[];
  comparison_report: Record<string, unknown>;
  risk_level: RiskLevel;
  risk_reasons: string[];
  report: string;
  runtime_metadata: Record<string, unknown>;
};

export type VersionInfo = {
  code_version?: string;
  model_version?: string;
  kb_version?: string;
  rule_version?: string;
  agent_llm_provider?: string;
  agent_llm_model?: string;
  [key: string]: unknown;
};

export type PinLocation = {
  pin_id: number;
  pin_name: string;
  pin_display_name?: string;
  polarity_role?: string;
  polarity_candidate_role?: string;
  hole_id: string;
  logic_loc?: [string, string];
  x_warp?: number;
  y_warp?: number;
  x_image?: number;
  y_image?: number;
  electrical_node_id?: string;
  electrical_net_id?: string;
  source?: string;
  source_by_view?: Record<string, string>;
};

export type ComponentWithPins = {
  component_id: string;
  component_type: string;
  package_type: string;
  polarity: string;
  confidence: number;
  pins: PinLocation[];
  bbox?: number[];
};

export type ElectricalNet = {
  electrical_net_id: string;
  power_role: string;
  member_node_ids: string[];
  member_hole_ids: string[];
};

export type CircuitAnalysisResult = {
  job_id: string;
  station_id: string;
  status: JobStatus;
  total_duration_ms: number;
  components: ComponentWithPins[];
  component_count: number;
  nets: ElectricalNet[];
  net_count: number;
  topology_graph: Record<string, unknown>;
  circuit_description: string;
  rail_assignments: RailAssignments;
};

export type Port = {
  port_id: string;
  pin_id: number;
  pin_name: string;
  component_id: string;
  component_type: string;
  hole_id: string;
  row_number: number;
  col_name: string;
  is_power_rail: boolean;
  power_role?: string;
  net_id: string;
  net_name?: string;
  x_image?: number;
  y_image?: number;
};

export type VisualizationNet = {
  net_id: string;
  net_name?: string;
  power_role: string;
  member_hole_ids: string[];
  member_port_ids: string[];
};

export type VisualizationComponent = {
  component_id: string;
  component_type: string;
  package_type: string;
  confidence: number;
  bbox?: number[];
  ports: Port[];
};

export type PortVisualizationResult = {
  job_id: string;
  station_id: string;
  status: JobStatus;
  total_duration_ms: number;
  ports: Port[];
  nets: VisualizationNet[];
  components: VisualizationComponent[];
  component_count: number;
  net_count: number;
  port_count: number;
  bounding_box?: {
    x_min: number;
    y_min: number;
    x_max: number;
    y_max: number;
  };
  statistics?: {
    power_rail_port_count: number;
    signal_port_count: number;
    isolated_port_count: number;
  };
};
