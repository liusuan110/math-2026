# LabGuardian Source Code Attachment

本附件包含 LabGuardian 项目的主要前后端源码与说明文档：

- `LabGuardian-Server/`: 后端服务、诊断流水线、知识库、配置示例、测试程序和部署脚本。
- `LabGuardian-web/`: 前端交互界面源码。

为控制附件体积并避免泄露本地环境信息，本附件未包含以下内容：

- `.git/`、`.venv/`、`node_modules/`、`dist/`
- 本地 `.env`、运行日志、上传缓存、输出缓存
- 大型模型权重、训练数据集、运行产物和个人密钥

运行方式请分别参考 `LabGuardian-Server/README.md` 与 `LabGuardian-web/README.md`。如需复现实机部署，请将模型权重、数据集和量化模型按项目 README 中说明放置到对应目录。
