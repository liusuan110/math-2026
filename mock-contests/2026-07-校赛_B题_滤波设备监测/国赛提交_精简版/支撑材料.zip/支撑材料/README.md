# 支撑材料运行说明

本压缩包包含 AI 工具使用详情、完整可运行的 Python 源程序、精确依赖版本和正文结论所对应的主要结果表。

赛题提供的原始附件不重复放入支撑材料。复现时，请将赛题原始文件按以下名称放入 `data/raw/`：

- `B题.docx`
- `附件1.xlsx`
- `附件2.xlsx`

在本目录执行：

```bash
uv run --with-requirements requirements-lock.txt python run_pipeline.py audit
uv run --with-requirements requirements-lock.txt python run_pipeline.py q1-data
uv run --with-requirements requirements-lock.txt python run_pipeline.py q1
uv run --with-requirements requirements-lock.txt python run_pipeline.py q2
uv run --with-requirements requirements-lock.txt python run_pipeline.py q3
uv run --with-requirements requirements-lock.txt python run_pipeline.py q4
```

各阶段会在 `data/processed/`、`data/results/` 和 `figures/generated/` 中重建中间数据、结果表与论文图。压缩包内 `data/results/` 已保留正文结论对应的主要正式结果。
