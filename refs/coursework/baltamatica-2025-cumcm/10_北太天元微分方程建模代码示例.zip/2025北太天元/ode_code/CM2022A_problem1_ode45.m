%clc;

%%问题参数
%附件1
omega = 1.4005; % 入射波浪频率 (s^{-1})
ma = 1335.535; % 垂荡附加质量 (kg) 
B = 656.3616; % 垂荡兴波阻尼系数 (N·s/m) 
f = 6250; % 波浪激励力振幅 (N) 

%附件2
mf = 4866; % 浮子质量 (kg)
mv = 2433; % 振子质量 (kg)
r = 1; %浮子半径
rho = 1025; % 海水密度 (kg/m^3) 
g = 9.8; % 重力加速度 (m/s^2)
k = 80000; % 弹簧刚度 (N/m) 

Aw = pi*r*r; %浮子水线面积






tic; % 开始计时

% 弹簧阻尼参数
is_linear = 1; %线性阻尼还是非线性阻尼
if is_linear 
    lambda = 10000;
    fZt=@(t,z) [z(2);...
            ( -(rho*g*Aw+k)*z(1) -(B+lambda)*z(2) +k*z(3) +lambda*z(4)+f*cos(omega*t) )/(mf+ma);...
            z(4);...
            ( k*z(1)+lambda*z(2)-k*z(3)-lambda*z(4) )/mv;
            ];
else
     lambda=@(z) 10000*abs(z(2)-z(4))^0.5;
     fZt=@(t,z) [z(2);...
            ( -(rho*g*Aw+k)*z(1) -(B+lambda(z))*z(2) +k*z(3) +lambda(z)*z(4)+f*cos(omega*t) )/(mf+ma);...
            z(4);...
            ( k*z(1)+lambda(z)*z(2)-k*z(3)-lambda(z)*z(4) )/mv;
            ];
end

%%数值方法对应的参数
%40*pi/omega~=180
T0=0;  T1=180;  h=1e-1; 
sol=ode45(fZt, [T0 T1], [0; 0; 0; 0]);  
t=T0:h:T1;
Z = deval(sol,t);

elapsedTime = toc; % 停止计时并获取运行时间
disp(['运行时间: ', num2str(elapsedTime), ' 秒']);

%% 提取题目要求的时间点结果
t_target = [10, 20, 40, 60, 100]; % 题目指定的时间点
indices = t_target / h + 1; % 转换为数组索引
% 线性阻尼结果
result_linear = [t(indices)', Z(1,indices)', Z(2,indices)', Z(3,indices)', Z(4,indices)'];
if is_linear 
    disp('线性阻尼结果');
else
     disp('非线性阻尼结果');
end
disp(result_linear);


%%  绘制位移-时间曲线
figure;
subplot(2,1,1);
plot(t, Z(1,:), 'b', t, Z(3,:), 'r');
if is_linear 
    title('线性阻尼下位移情况');
else
     title('非线性阻尼下位移情况');
end
xlabel('时间 (s)'); ylabel('位移 (m)');
legend('浮子', '振子');

subplot(2,1,2);
plot(t, Z(2,:), 'b', t, Z(4,:), 'r');
if is_linear 
    title('线性阻尼下速度情况');
else
     title('非线性阻尼下速度情况');
end
xlabel('时间 (s)'); ylabel('速度 (m/s)');
legend('浮子', '振子');