odefun3=@(x, y) [y(2); (1-y(1)^2)*y(2)-2*y(1)]; 
sol=ode45(odefun3, [0 2], [2 0]);  
x=0:0.01:2
y=deval(sol,x);
plot(x,y(1,:),'-o', x,y(2,:),'-.')   
