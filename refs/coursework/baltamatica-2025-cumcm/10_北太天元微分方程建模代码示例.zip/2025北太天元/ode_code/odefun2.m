function  dy=odefun2(x,y)   
        dy=[y(2); (1/5*sqrt(1+y(2)^2))/(1-x)]; 
 end      
